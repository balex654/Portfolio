package gui;

public class GUItest {
	public static void main(String[] args){
		Buttons b = new Buttons();
		b.GUI();
	}
}
