package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.SetsRepo;
import com.example.demo.model.sets;

@RestController
public class SetsController {

	@Autowired
	SetsRepo rep;
	
	@RequestMapping(method = RequestMethod.POST, path = "/addSet")
	public String saveSet(sets s) {
		rep.save(s);
		return "New Set " + s.toString();
	}
	
	@RequestMapping(method = RequestMethod.GET, path = "/sets/{s_id}")
	public List<sets> findSetByeID(@PathVariable("s_id") int id){
		List<sets> results = rep.findAllByeID(id);
		return results;
	}
	
	@RequestMapping(method = RequestMethod.GET, path = "/setsByWID/{w_id}")
	public List<sets> findSetBywID(@PathVariable("w_id") int id){
		List<sets> results = rep.findAllBywID(id);
		return results;
	}
}
