package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.UserRepo;
import com.example.demo.model.user;

@RestController
public class UserController {
	
	@Autowired
	UserRepo rep;
	
	@RequestMapping(method = RequestMethod.POST, path = "/addUser")
	public String saveUser(user user) {
		rep.save(user);
		return "New User " + user.toString();
	}
	
	@RequestMapping(method = RequestMethod.GET, path = "/users")
	public List<user> getUsers(){
		List<user> users = (List<user>) rep.findAll();
		System.out.println(users.toString());
		return users;
	}
	
	@RequestMapping(method = RequestMethod.GET, path = "/users/{userName}")
	public List<user> findUserByuserName(@PathVariable("userName") String userName){
		List<user> results = rep.findAllByuserName(userName);
		return results;
	}
}