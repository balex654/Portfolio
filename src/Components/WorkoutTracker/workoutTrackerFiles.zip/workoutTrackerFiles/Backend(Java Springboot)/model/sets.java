package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="sets")
public class sets {
	
	@Id
	@Column(name="s_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int sID;

	@Column(name="reps")
	private int reps;
	
	@Column(name="weight")
	private int weight;
	
	@Column(name="orderNum")
	private int orderNum;
	
	@Column(name="e_id")
	private int eID;
	
	@Column(name="w_id")
	private int wID;
	
	public int getS_id() {
		return sID;
	}

	public void setS_id(int s_id) {
		this.sID = s_id;
	}

	public int getReps() {
		return reps;
	}

	public void setReps(int reps) {
		this.reps = reps;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}

	public int getE_id() {
		return eID;
	}

	public void setE_id(int e_id) {
		this.eID = e_id;
	}
	
	public int getW_id() {
		return wID;
	}
	
	public void setW_id(int w_id) {
		this.wID = w_id;
	}

	@Override
	public String toString() {
		return "sets [s_id=" + sID + ", reps=" + reps + ", weight=" + weight + ", orderNum=" + orderNum + ", e_id="
				+ eID + ", w_id=" + wID + "]";
	}
}
