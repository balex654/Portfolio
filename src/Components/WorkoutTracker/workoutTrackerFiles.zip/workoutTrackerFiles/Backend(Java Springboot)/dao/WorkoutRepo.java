package com.example.demo.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.workout;

public interface WorkoutRepo extends CrudRepository<workout, Integer> {
	
	List<workout> findAllByuserID(int id);
}
