package com.example.demo.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.sets;

public interface SetsRepo extends CrudRepository<sets, Integer>{
	List<sets> findAllByeID(int id);
	
	List<sets> findAllBywID(int id);
}
