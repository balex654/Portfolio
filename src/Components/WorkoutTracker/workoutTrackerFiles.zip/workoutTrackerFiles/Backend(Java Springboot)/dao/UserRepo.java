package com.example.demo.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.user;

public interface UserRepo extends CrudRepository<user, Integer>{
	List<user> findAllByuserName(String name);
}
