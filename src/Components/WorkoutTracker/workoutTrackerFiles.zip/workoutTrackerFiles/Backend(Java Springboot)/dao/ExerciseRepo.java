package com.example.demo.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.exercise;

public interface ExerciseRepo extends CrudRepository<exercise, Integer>{
	
	List<exercise> findAllBywID(int id);
	
}
