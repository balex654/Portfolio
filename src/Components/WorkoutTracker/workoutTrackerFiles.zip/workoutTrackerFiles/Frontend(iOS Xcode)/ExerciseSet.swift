//
//  Set.swift
//  WorkoutTracker
//
//  Created by Ben Alexander on 1/13/20.
//  Copyright © 2020 Ben Alexander. All rights reserved.
//

import Foundation

class ExerciseSet {
    
    private var reps: String
    private var weight: String
    private var orderNum: Int
    private var exerciseID: Int
    private var exerciseOrder: Int
    
    init(reps: String, weight: String, orderNum: Int, exerciseID: Int, exerciseOrder: Int) {
        self.reps = reps
        self.weight = weight
        self.orderNum = orderNum
        self.exerciseID = exerciseID
        self.exerciseOrder = exerciseOrder
    }
    
    func showReps() -> String {
        return reps
    }
    
    func showWeight() -> String {
        return weight
    }
    
    func showOrderNum() -> Int {
        return orderNum
    }
    
    func showExerciseID() -> Int {
        return exerciseID
    }
    func setExerciseID(exerciseID: Int) -> Void {
        self.exerciseID = exerciseID
    }
    
    func showExerciseOrder() -> Int {
        return exerciseOrder
    }
}
