//
//  CreateAccountViewController.swift
//  WorkoutTracker
//
//  Created by Ben Alexander on 1/25/20.
//  Copyright © 2020 Ben Alexander. All rights reserved.
//

import UIKit

class CreateAccountViewController: UIViewController {

    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func createPressed(_ sender: Any) {
        let userName = username.text!
        var urlStr = "https://workoutapp-262402.appspot.com/addUser?"
        urlStr += "firstName=" + firstName.text!
        urlStr += "&lastName=" + lastName.text!
        urlStr += "&userName=" + username.text!
        urlStr += "&password=" + password.text!
        
        let url = URL(string: urlStr)!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let task = URLSession.shared.dataTask(with: request) {(data, response, error) in
            
            self.getUser(userName: userName)
        }
        task.resume()
        
    }
    
    func getUser(userName: String) -> Void {
        let urlStr = "https://workoutapp-262402.appspot.com/users/" + userName
        let url = URL(string: urlStr)!
        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            guard let data = data else {return}
            let result = JSON(data)
            
            Variables.userID = result[0]["userName"].intValue
            Variables.username = userName
            self.goToHome()
        }
        task.resume()
    }
    
    func goToHome() -> Void {
        DispatchQueue.main.async {
            let vc = self.storyboard!.instantiateViewController(withIdentifier: "homeScreen")
            self.present(vc, animated: true, completion: nil)
        }
    }
}
