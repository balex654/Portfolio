//
//  Variables.swift
//  WorkoutTracker
//
//  Created by Ben Alexander on 1/8/20.
//  Copyright © 2020 Ben Alexander. All rights reserved.
//

import Foundation

struct Variables {
    static var username: String = ""
    static var userID: Int = 1
    static var workouts: JSON? = JSON()
    static var exercises: JSON? = JSON()
    static var sets: JSON? = JSON()
}
