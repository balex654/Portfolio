//
//  HomeScreenViewController.swift
//  WorkoutTracker
//
//  Created by Ben Alexander on 1/8/20.
//  Copyright © 2020 Ben Alexander. All rights reserved.
//

import UIKit
import SwiftyJSON

class HomeScreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    

    @IBAction func viewHistory(_ sender: Any) {
         
        let url = URL(string: "https://workoutapp-262402.appspot.com/workouts/" + String(Variables.userID))!
        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            guard let data = data else {return}
            
            let result = JSON(data)
            Variables.workouts = result
            
            self.goToHistory()
        }
        task.resume()
    }
    
    @IBAction func logoutPressed(_ sender: Any) {
        Variables.username = ""
        Variables.userID = 0
    }
    
    func goToHistory() -> Void {
        DispatchQueue.main.async {
            let vc = self.storyboard!.instantiateViewController(identifier: "historyScreen")
            self.present(vc, animated: true, completion: nil)
        }
    }

}
