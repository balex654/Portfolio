//
//  WorkoutViewController.swift
//  WorkoutTracker
//
//  Created by Ben Alexander on 1/9/20.
//  Copyright © 2020 Ben Alexander. All rights reserved.
//

import UIKit

class WorkoutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

}
