//
//  Exercise.swift
//  WorkoutTracker
//
//  Created by Ben Alexander on 1/14/20.
//  Copyright © 2020 Ben Alexander. All rights reserved.
//

import Foundation

class Exercise{
    
    private var name: String
    private var eID: Int
    
    init(name: String, eID: Int) {
        self.name = name
        self.eID = eID
    }
    
    func showName() -> String {
        return name
    }
    
    func showEID() -> Int {
        return eID
    }
    
    func setEID(eID: Int) -> Void {
        self.eID = eID
    }
}
