//
//  ViewController.swift
//  WorkoutTracker
//
//  Created by Ben Alexander on 1/4/20.
//  Copyright © 2020 Ben Alexander. All rights reserved.
//

import UIKit
import SwiftyJSON


class ViewController: UIViewController {

    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    var dbID: Substring = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func loginPressed(_ sender: Any) {
        let givenPW = password.text!
        
        let url = URL(string: "https://workoutapp-262402.appspot.com/users/" + username.text!)!
        
        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            guard let data = data else {return}
        
            let user = String(data: data, encoding: .utf8)!
            let items = user.components(separatedBy: ",")
            
            let pwStr = items[4]
            var start = pwStr.index(pwStr.startIndex, offsetBy: 12)
            var end = pwStr.index(pwStr.endIndex, offsetBy: -3)
            var range = start..<end
            let dbPW = pwStr[range]
            
            let idStr = items[0]
            start = idStr.index(idStr.startIndex, offsetBy: 7)
            end = idStr.index(idStr.endIndex, offsetBy: 0)
            range = start..<end
            self.dbID = idStr[range]
            
            if dbPW == givenPW {
                self.goToHome()
            }
        }
        task.resume()
    }
    
    func goToHome() -> Void {
        print("right password")
        DispatchQueue.main.async {
            Variables.username = self.username.text!
            Variables.userID = Int(String(self.dbID))!
            let vc = self.storyboard!.instantiateViewController(withIdentifier: "homeScreen")
            self.present(vc, animated: true, completion: nil)
        }
    }
    
}

