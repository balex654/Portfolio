//
//  WorkoutTableViewCell.swift
//  workoutApp
//
//  Created by Ben Alexander on 1/20/19.
//  Copyright © 2019 Ben Alexander. All rights reserved.
//

import UIKit

class WorkoutTableViewCell: UITableViewCell {

    @IBOutlet weak var exerciseName: UILabel!
    @IBOutlet weak var reps1: UILabel!
    @IBOutlet weak var reps2: UILabel!
    @IBOutlet weak var reps3: UILabel!
    @IBOutlet weak var reps4: UILabel!
    @IBOutlet weak var weight1: UILabel!
    @IBOutlet weak var weight2: UILabel!
    @IBOutlet weak var weight3: UILabel!
    @IBOutlet weak var weight4: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
