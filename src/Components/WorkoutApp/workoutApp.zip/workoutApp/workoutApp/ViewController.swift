//
//  ViewController.swift
//  workoutApp
//
//  Created by Ben Alexander on 1/5/19.
//  Copyright © 2019 Ben Alexander. All rights reserved.
//

import UIKit
import os.log
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let appUsed = UserDefaults.standard.object(forKey: "appUsed")
        if (appUsed != nil) {
            /*
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
            //request.predicate = NSPredicate(format: "age = %@", "12")
            request.returnsObjectsAsFaults = false
            do {
                let result = try managedContext.fetch(request)
                for data in result as! [NSManagedObject] {
                    print(data.value(forKey: "username") as! String)
                }
                
            } catch {
                
                print("Failed")
            }
            */
        }
    }


}

