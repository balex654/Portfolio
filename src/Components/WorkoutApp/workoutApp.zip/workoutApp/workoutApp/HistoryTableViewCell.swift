//
//  WorkoutTableViewCell.swift
//  workoutApp
//
//  Created by Ben Alexander on 1/16/19.
//  Copyright © 2019 Ben Alexander. All rights reserved.
//

import UIKit

class HistoryTableViewCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
