CREATE USER 'cs363project' IDENTIFIED WITH mysql_native_password BY 'cs363balex';
GRANT SELECT ON project.* TO 'cs363project';
GRANT DROP ON project.* TO 'cs363project';
GRANT CREATE ON project.* TO 'cs363project';
GRANT INSERT ON project.* TO 'cs363project';
GRANT DELETE ON project.* TO 'cs363project';
