use project;

drop table if exists appusers;
create table appusers(
name varchar(40),
pwd varchar(40),
privilege varchar(10),
primary key(name));

set @pwd='cs363f19';
insert into appusers values ('testUser1', sha1(@pwd), 'all');
insert into appusers values ('testUser2', sha1(@pwd), 'readonly');

select * from appusers where (name='testUser1' or name = 'testUser2') and pwd=sha1(@pwd);