-- Q1

prepare Q1 from
	'select t.retweet_count, t.textbody, t.screen_name, u.category, u.sub_category from tweet t, userAccount u where 
	t.screen_name = u.screen_name 
	and t.year = ? and t.month = ?
	order by t.retweet_count desc limit ?';
set @yr = 2016;
set @mn = 01;
set @lm = 10;
execute Q1 using @yr, @mn, @lm;
deallocate prepare Q1;

-- Q3
prepare Q3 from
	'select distinct h.hname, count(distinct u.state) as num_states, group_concat(distinct u.state) as states
	from tweet t, hashtag h, userAccount u where 
	h.h_tid = t.tid and t.screen_name = u.screen_name and u.state != "na" and SUBSTRING(t.posted, 1, 4) = ?
	group by h.hname order by num_states desc limit ?';
set @yr = "2016";
set @lm = 10;
execute Q3 using @yr, @lm;
deallocate prepare Q3;

-- Q6
prepare Q6 from
	'select x.screen_name, x.state from (select distinct u.screen_name, u.state, u.numFollowers from userAccount u, hashtag h, tweet t where 
	h.h_tid = t.tid and t.screen_name = u.screen_name and h.hname in ("HappyNewYear","NewYear","NewYears","NewYearsDay")) x
	order by x.numFollowers desc limit ?';
set @lm = 12;
execute Q6 using @lm;
deallocate prepare Q6;

-- Q9
prepare Q9 from
	'SELECT DISTINCT u.screen_name, u.category, u.numFollowers
	FROM userAccount u 
	WHERE u.sub_category=?
	ORDER BY u.numFollowers DESC
	LIMIT 10';
set @sc = 'GOP';
execute Q9 using @sc;
deallocate prepare Q9;

-- Q10
prepare Q10 from
	'select distinct h.hname, u.state from hashtag h, userAccount u, tweet t where
	h.h_tid = t.tid and t.screen_name = u.screen_name and u.state in ("Ohio", "Alaska", "Alabama")
	and t.month = 1 and t.year = 2016 order by h.hname asc';
set @month = 1;
set @year = 2016;
execute Q10 using @month, @year;
deallocate prepare Q10;


-- Q11
prepare Q11 from
	'select t.textbody, h.hname, u.screen_name, u.sub_category from tweet t, hashtag h, userAccount u
	where h.h_tid = t.tid and t.screen_name = u.screen_name and u.state = ? and h.hname = ?
	and (u.sub_category = "GOP" or u.sub_category = "democrat") and t.month = ? AND t.year = ? limit ?';
set @hname = 'Ohio';
set @state = 'Ohio';
set @month = 1;
set @year = 2016;
set @lm = 5;
execute Q11 using @state, @hname, @month, @year, @lm;
deallocate prepare Q11;

-- Q15
SELECT u.screen_name, u.ofstate, GROUP_CONCAT(url.url) Listof_urls
FROM user u, tweets t, url
WHERE u.screen_name = t.posting_user AND url.tid = t.tid AND MONTH(t.posted) = '01' AND YEAR(t.posted) = '2016'AND sub_category = 'GOP'
GROUP BY u.screen_name, u.ofstate limit 100

-- Q18
select user.screen_name, user.ofstate, group_concat(distinct tweets.posting_user order by tweets.posting_user asc separator ',') as postingUsers 
from user
 join mentioned on user.screen_name= mentioned.screen_name
 join tweets on tweets.tid= mentioned.tid 
 join user as u on u.screen_name = tweets.posting_user
where u.sub_category= "GOP" 
and month(tweets.posted)='01' 
and year(tweets.posted) = '2016' 
group by user.screen_name, user.ofstate
order by count(tweets.posting_user) desc limit 10;

-- Q23
SELECT DISTINCT h.hastagname, COUNT(h.hastagname) AS cnt
FROM hashtag h
INNER JOIN tweets t ON h.tid = t.tid
INNER JOIN user u ON t.posting_user = u.screen_name
WHERE u.sub_category = 'GOP' and YEAR(t.posted)  = '2016' AND MONTH(t.posted) IN ('01','02','03')
GROUP BY h.hastagname
ORDER BY cnt DESC
LIMIT 10;

 


