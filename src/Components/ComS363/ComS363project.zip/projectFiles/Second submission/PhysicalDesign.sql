-- Q1

-- Add year, month and day columns to tweet
alter table tweet add year int;
alter table tweet add month int;
alter table tweet add day int;
-- Fill the year, day and month columns
update tweet set year = substring(posted, 1, 4);
update tweet set month = substring(posted, 6, 2);
update tweet set day = substring(posted, 9, 2);
-- Add indexes for year, day and month
create index tweetDate on tweet(year, month, day);

-- Q3
-- Query uses the previously created index
create index tweetDate on tweet(year, month, day);

-- Q6
create index hnameIndex on hashtag(hname);

-- Q9
create index subCategory on userAccount(sub_category);

-- Q10
-- Query uses the previously created index
create index tweetDate on tweet(year, month, day);

-- Q11
-- Created new index 'state' and used previously created indexes
create index state on userAccount(state);

-- Q15
-- Instead of joining the tweet id and the url,directly selecting from tweet, user and url table optimizes the execution time of the query. 

-- Q18
-- Creating a full text index on the primary key optimizes the execution time of the server on the query.

-- Q23
-- Inner joining the tweets on hashtag and inner joining the user on the tweet optimizes the execution time of the query.

