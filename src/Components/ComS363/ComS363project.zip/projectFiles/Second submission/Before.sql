-- Q1
prepare Q1 from
	'select t.retweet_count, t.textbody, t.screen_name, u.category, u.sub_category from tweet t, userAccount u where 
	t.screen_name = u.screen_name 
	and SUBSTRING(t.posted, 1, 4) = ? and SUBSTRING(t.posted, 6, 2) = ?
	order by t.retweet_count desc limit ?';
set @yr = "2016";
set @mn = "01";
set @lm = 10;
execute Q1 using @yr, @mn, @lm;
deallocate prepare Q1;

-- Q3
prepare Q3 from
	'select distinct h.hname, count(distinct u.state) as num_states, group_concat(distinct u.state) as states
	from tweet t, hashtag h, userAccount u where 
	h.h_tid = t.tid and t.screen_name = u.screen_name and u.state != "na" and t.year = ?
	group by h.hname order by num_states desc limit ?';
set @yr = 2016;
set @lm = 10;
execute Q3 using @yr, @lm;
deallocate prepare Q3;

-- Q6
prepare Q6 from
	'select x.screen_name, x.state from (select distinct u.screen_name, u.state, u.numFollowers from userAccount u, hashtag h, tweet t where 
	h.h_tid = t.tid and t.screen_name = u.screen_name and find_in_set(h.hname, ?) != 0) x
	order by x.numFollowers desc limit ?';
set @tags = 'HappyNewYear,NewYear,NewYears,NewYearsDay';
set @lm = 12;
execute Q6 using @tags, @lm;
deallocate prepare Q6;

-- Q9
prepare Q9 from
	'SELECT DISTINCT u.screen_name, u.category, u.numFollowers
	FROM userAccount u 
	WHERE u.sub_category=?
	ORDER BY u.numFollowers DESC
	LIMIT 10';
set @sc = 'GOP';
execute Q9 using @sc;
deallocate prepare Q9;

-- Q10
prepare Q10 from
	'select distinct h.hname, u.state from hashtag h, userAccount u, tweet t where
	h.h_tid = t.tid and t.screen_name = u.screen_name and u.state in ("Ohio", "Alaska", "Alabama")
	and SUBSTRING(t.posted, 6, 2) = ? AND SUBSTRING(t.posted, 1, 4) = ? order by h.hname asc';
set @month = "01";
set @year = "2016";
execute Q10 using @year, @month;
deallocate prepare Q10;


-- Q11
prepare Q11 from
	'select t.textbody, h.hname, u.screen_name, u.sub_category from tweet t, hashtag h, userAccount u
	where h.h_tid = t.tid and t.screen_name = u.screen_name and u.state = ? and h.hname = ?
	and (u.sub_category = "GOP" or u.sub_category = "democrat") and SUBSTRING(t.posted, 6, 2) = ? AND SUBSTRING(t.posted, 1, 4) = ? limit ?';
set @hname = 'gop';
set @state = 'Ohio';
set @month = '01';
set @year = '2016';
set @lm = 5;
execute Q11 using @state, @hname, @month, @year, @lm;
deallocate prepare Q11;

--Q15
SELECT u.screen_name, u.ofstate, GROUP_CONCAT(url.url) AS all_urls
FROM url url
INNER JOIN tweets t ON url.tid = t.tid
INNER JOIN user u ON t.posting_user = u.screen_name
WHERE MONTH(t.posted) ='01'  AND YEAR(t.posted) = '2016' AND sub_category ='GOP'
GROUP BY u.screen_name, u.ofstate limit 100;

--Q18
select user.screen_name, user.ofstate, group_concat(distinct 
tweets.posting_user order by tweets.posting_user asc separator ',') as postingUsers 
from user
 join mentioned on user.screen_name= mentioned.screen_name
 join tweets on tweets.tid= mentioned.tid 
 join user as u on u.screen_name = tweets.posting_user
where u.sub_category= "GOP" 
and month(tweets.posted)='01'
and year(tweets.posted) = '2016' 
group by user.screen_name, user.ofstate
order by count(tweets.posting_user) desc limit 10;


--Q23

SELECT DISTINCT h.hastagname, COUNT(h.hastagname) AS count
FROM hashtag h, user u, tweets t
WHERE (MONTH(t.posted)='01' or MONTH(t.posted)='02' or MONTH(t.posted)='03') AND YEAR(t.posted) = '2016' AND u.sub_category='GOP'
 and h.tid = t.tid AND t.posting_user = u.screen_name
GROUP BY h.hastagname
ORDER BY count DESC
LIMIT 10;

-- I
prepare I from
	'insert into userAccount (screen_name, uname, sub_category, category, state, numFollowing, numFollowers) values(?, ?, ?, ?, ?, ?, ?);';
set @sn = 'test';
set @un = 'test';
set @sc = 'GOP';
set @c = 'Senator';
set @state = 'Minnesota';
set @nfollowing = 0;
set @nfollowers = 0;
execute I using @sn, @un, @sc, @c, @state, @nfollowing, @nfollowers;
deallocate prepare I;

-- D
-- Database already has necessary triggers created to delete all associated user data
prepare D from
	'delete from userAccount where screen_name = ?';
set @sn = 'test';
execute D using @sn;
deallocate prepare D;

-- To clean the data:
update userAccount set state = 'Florida' where state = 'FL';
update userAccount set state = 'Nebraska' where state = 'NE';
update userAccount set state = 'Iowa' where state = 'IA';
update userAccount set state = 'Arizona' where state = 'AZ';
update userAccount set state = 'Illinois' where state = 'IL';
update userAccount set state = 'South Dakota' where state = 'SD';
update userAccount set state = 'Wisconsin' where state = 'WI';

