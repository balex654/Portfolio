package com.example.joner.socialman;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

/**
 * This adapter class is used by the Conversations activity. When a user taps on a certain item in the
 * recyclerView, they are brought to the Chat associated with the friend that they tapped on.
 */
public class TempAdapter extends RecyclerView.Adapter<TempAdapter.ViewHolder> {
    @NonNull
    private static final String TAG = "MyAdapter";
    private ArrayList<User> friends;
    private Context mContext;

    public TempAdapter(@NonNull Context c, ArrayList<User> friends) {
        this.mContext = c;
        this.friends = friends;
    }

    /**
     * The View in this method is associated with temp_layout_friend which show the layout of the list of
     * friends
     * @param viewGroup
     * @param i
     * @return viewholder
     */
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.temp_layout_friend, viewGroup, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    /**
     * In the onClick part of this method, the friends that the user clicked on is sent to the chat activity
     * and then the user is brought to the chat
     * @param viewHolder
     * @param i
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {
        Log.d(TAG, "OnBindViewHolder: called");

        //Load and set image
        /*
        Glide.with(mContext)
                .asBitmap()
                .load(friends.get(i).getImageURL())
                .into(viewHolder.image);
        */
        //Set name
        viewHolder.name.setText(friends.get(i).getName());
        viewHolder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, Chat.class);
                intent.putExtra("friend", friends.get(i).getName());

                Variables.currentChatNumber = i;

                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return friends.size();
    }

    /**
     * This class sets the Views of all the items in the layout
     */
    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView name;
        RelativeLayout parent;



        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.friend_image);
            name = itemView.findViewById(R.id.friend_name);
            parent = itemView.findViewById(R.id.friend_rl);
        }
    }

}
