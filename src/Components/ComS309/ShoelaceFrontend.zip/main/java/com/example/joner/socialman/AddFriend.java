package com.example.joner.socialman;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class AddFriend extends AppCompatActivity {

    private String TAG = "AddFriend";
    private ArrayList<User> users;
    private FriendsAdapter adapter;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_chat:
                Intent i = new Intent(AddFriend.this, Chat.class);
                startActivity(i);

            default:
                return super.onOptionsItemSelected(item);

        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Add friends");
        setSupportActionBar((Toolbar) findViewById(R.id.my_toolbar));
        setContentView(R.layout.activity_add_friend);
        users = new ArrayList<>();
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = "http://proj309-mg-01.misc.iastate.edu:8080/users/";

        initRecyclerView();

        JsonArrayRequest request = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.d("Response", response.toString());
                        users.clear();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                User temp = User.fromJson(response.getJSONObject(i));
                                if (!User.getCurrentUser().getFriends().contains(temp) && !temp.equals(User.getCurrentUser()))
                                    users.add(temp);

                                adapter.notifyDataSetChanged();
                                Log.d("Adapter size: ", String.valueOf(adapter.getItemCount()));


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Error " + error.getMessage());
                        error.printStackTrace();
                    }
                }

        );
        queue.add(request);


    }

    private void initRecyclerView() {
        Log.d(TAG, "initRecyclerView called");
        recyclerView = findViewById(R.id.addFriends_recyclerview);
        adapter = new FriendsAdapter(this, users, true);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
    }
}
