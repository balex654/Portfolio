package com.example.joner.socialman;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;

/**
 * This class manages the Facebook login and Facebook API requests
 */
public class FacebookLogin extends AppCompatActivity {

    String TAG = "FacebookLogin";
    private CallbackManager callbackManager;
    private URL profilePicture;
    private String userId, firstName, lastName;
    private LoginButton FBloginButton;

    private AccessToken token;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facebook_login);
        //TODO Figure out if there is something better to be using than this deprecated method
        FacebookSdk.sdkInitialize(getApplicationContext());
        callbackManager = CallbackManager.Factory.create();
        //TODO same here
        AppEventsLogger.activateApp(this);

        FBloginButton = findViewById(R.id.FBlogin_button);

        FacebookCallback<LoginResult> callback = new FacebookCallback<LoginResult>() {
            /**
             * If the Facebook login is successful, this method will execute. The AccessToken is stored
             * and graphRequest is called
             * @param loginResult
             */
            @Override
            public void onSuccess(LoginResult loginResult) {
                // App code
                token = loginResult.getAccessToken();
                Variables.getInstance().setFBAccessToken(token);
                Variables.getInstance().setLoggedInFacebook(true);
                Variables.getInstance().getPostsFB().clear();

                Gson gson = new Gson();
                String json =  gson.toJson(token);

                SharedPreferences.Editor editor = getSharedPreferences("FB login data", MODE_PRIVATE).edit();
                editor.putString("Access token", json);
                editor.apply();

                graphRequest(token);
            }

            @Override
            public void onCancel() {
                Log.d(TAG, "onCancel called");

            }

            @Override
            public void onError(FacebookException exception) {
                Log.d(TAG, "onError called: " + exception.getMessage());
            }
        };
        FBloginButton.setReadPermissions("public_profile", "user_photos", "user_posts");
        FBloginButton.registerCallback(callbackManager, callback);
        AccessToken accessToken = AccessToken.getCurrentAccessToken();
        boolean isLoggedIn = accessToken != null && !accessToken.isExpired();
        LoginManager.getInstance().logInWithReadPermissions(FacebookLogin.this, Arrays.asList("public_profile", "user_posts", "user_photos"));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * Helper method for the onSuccess method. This method requests all relevant user data from Facebook
     * and add it to the FBPost in the Variables class
     * @param token
     */
    private void graphRequest(AccessToken token){
        new GraphRequest(
                token,
                "/me?fields=posts,photos,first_name,last_name",
                null,
                HttpMethod.GET,
                new GraphRequest.Callback() {
                    public void onCompleted(GraphResponse response) {
                        Log.e(TAG, response.toString());
                        try {
                            JSONObject object = response.getJSONObject();
                            userId = object.getString("id");
                            profilePicture = new URL("https://graph.facebook.com/" + userId + "/picture?width=500&height=500");
                            Log.d("FB profile picture", profilePicture.toString());
                            if (object.has("first_name"))
                                firstName = object.getString("first_name");
                            if (object.has("last_name"))
                                lastName = object.getString("last_name");
                            if (object.has("posts")) {
                                JSONObject user_posts = object.getJSONObject("posts");
                                JSONArray a = user_posts.getJSONArray("data");
                                for (int i = 0; i < a.length(); i++) {
                                    JSONObject b = a.getJSONObject(i);
                                    if (b.has("message")) {

                                        Post newPost = new Post.PostBuilder()
                                                .addName(firstName + " " + lastName)
                                                .addSource("Facebook")
                                                .addDescription(b.getString("message"))
                                                .addImageURL(profilePicture.toString())
                                                .addTimePosted("N/A")
                                                .build();
                                        Variables.getInstance().addFBPost(newPost);
                                    }
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }
                    }
                }
        ).executeAsync();
    }

}
