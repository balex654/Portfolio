package com.example.joner.socialman;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.DefaultLogger;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterApiClient;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterAuthToken;
import com.twitter.sdk.android.core.TwitterConfig;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.core.identity.TwitterAuthClient;
import com.twitter.sdk.android.core.identity.TwitterLoginButton;
import com.twitter.sdk.android.core.models.Tweet;

import java.util.List;

import retrofit2.Call;

/**
 * This class manages the Twitter login and Facebook API requests
 */
public class TwitterLogin extends AppCompatActivity {

    private TwitterLoginButton loginButton;
    private TwitterSession session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TwitterConfig config = new TwitterConfig.Builder(this)
                .logger(new DefaultLogger(Log.DEBUG))
                .twitterAuthConfig(new TwitterAuthConfig("Mra5cn6PbohYlevMYtpIxoLnI", "4PHG0u6MU7D0qRduKwh9sa61uLceODLWf2ZTXcKZvALToZGG5r"))
                .debug(true)
                .build();
        Twitter.initialize(config);
        setContentView(R.layout.activity_twitter_login);

        loginButton = findViewById(R.id.twitter_login_button);
        loginButton.setCallback(new Callback<TwitterSession>() {
            /**
             * If the Twitter login is successful this method is called. The TwitterSession is stored and getTweets is called
             * @param result
             */
            @Override
            public void success(Result<TwitterSession> result) {
                // Do something with result, which provides a TwitterSession for making API calls
                session = TwitterCore.getInstance().getSessionManager().getActiveSession();
                Variables.getInstance().setTwitterSession(session);
                TwitterAuthToken authToken = session.getAuthToken();
                TwitterAuthClient authClient = new TwitterAuthClient();
                boolean isLoggedIn = !authToken.isExpired();
                Variables.getInstance().setLoggedInTwitter(isLoggedIn);
                Variables.getInstance().getPostsTwitter().clear();

                Gson gson = new Gson();
                String json =  gson.toJson(session);

                SharedPreferences.Editor editor = getSharedPreferences("Twitter login data", MODE_PRIVATE).edit();
                editor.putString("session", json);
                editor.apply();

                getTweets();
            }

            @Override
            public void failure(TwitterException exception) {
                Log.d("Twitter Failure", exception.toString());
                Toast.makeText(TwitterLogin.this, "Failed login", Toast.LENGTH_LONG).show();
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Pass the activity result to the login button.
        loginButton.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * This is a helper method for the onSuccess method above. It will make a request to the Twitter API
     * and get relevant post data back and save it in the Variables class
     */
    private void getTweets() {
        TwitterApiClient client = TwitterCore.getInstance().getApiClient(session);
        Call<List<Tweet>> call = client.getStatusesService().homeTimeline(200, null, null, false, false, true, true);
        call.enqueue(new Callback<List<Tweet>>() {
            @Override
            public void success(Result<List<Tweet>> result) {
                List<Tweet> tweets = result.data;

                for (int i = 0; i < tweets.size(); i++) {
                    Tweet tweet = tweets.get(i);
                    String caption = tweet.text;
                    String source = tweet.user.name;
                    String imageURL = tweet.user.profileImageUrl;
                    String time = tweet.createdAt;


                    Variables.getInstance().addTwitterPost(new Post.PostBuilder()
                            .addSource("Twitter")
                            .addDescription(caption)
                            .addImageURL(imageURL)
                            .addName(source)
                            .addTimePosted(time)
                            .build());
                }

            }

            @Override
            public void failure(TwitterException exception) {
                Toast.makeText(TwitterLogin.this, "Failed to authenticate. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
