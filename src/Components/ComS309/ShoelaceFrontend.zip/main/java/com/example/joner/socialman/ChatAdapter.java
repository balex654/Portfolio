package com.example.joner.socialman;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.google.gson.internal.LinkedTreeMap;

import java.util.ArrayList;

import static android.graphics.Color.rgb;

/**
 * This Adapter is used by the Chat activity to show the items in the recyclerView
 */
public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ViewHolder> {
    @NonNull
    private static final String TAG = "MyAdapter";
    private ArrayList<Post> messages;
    private Context mContext;

    public ChatAdapter(@NonNull Context c, ArrayList<Post> messages) {
        this.mContext = c;
        this.messages = messages;
    }

    /**
     * The View in this method is associated with chat_layout which shows the layout of the list of
     * messages
     * @param viewGroup
     * @param i
     * @return
     */
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.chat_layout, viewGroup, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    /**
     * This method sets the text message associated with every item in the recyclerView
     * @param viewHolder
     * @param i
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {
        Log.d(TAG, "OnBindViewHolder: called");

        Log.d("chatmessages", messages.toString());
        Post p = messages.get(i);
        String s = p.getDescription();
        viewHolder.message.setText(messages.get(i).getDescription());

    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    /**
     * This class sets the View to the TextView object
     */
    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView message;
        RelativeLayout parent;



        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            message = itemView.findViewById(R.id.message);
            message.setTextColor(Color.BLACK);
            parent = itemView.findViewById(R.id.chat_rl);
        }
    }

}
