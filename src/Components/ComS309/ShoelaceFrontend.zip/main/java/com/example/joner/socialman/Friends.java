package com.example.joner.socialman;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

/**
 * Lists friends for current user
 */
public class Friends extends AppCompatActivity {

    private String TAG = "Friends";
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<User> friends;
    private FloatingActionButton addFriend;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_chat:
                Intent i = new Intent(Friends.this, Chat.class);
                startActivity(i);

            default:
                return super.onOptionsItemSelected(item);

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onResume() {
        super.onResume();
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = new StringBuilder()
                .append("http://proj309-mg-01.misc.iastate.edu:8080/users/")
                .append(User.getCurrentUser().getId())
                .append("/friends")
                .toString();

        Log.d("Array Request", url);


        JsonArrayRequest request = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.d("Response", response.toString());
                        User.getCurrentUser().getFriends().clear();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                Log.d("postFromJSON", String.valueOf(i));
                                User.getCurrentUser().getFriends().add(User.fromJson(response.getJSONObject(i)));
                                adapter.notifyDataSetChanged();
                                Log.d("Adapter size: ", String.valueOf(adapter.getItemCount()));


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Error " + error.getMessage());
                        error.printStackTrace();
                    }
                }

        );
        queue.add(request);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);
        addFriend = findViewById(R.id.addFriend);
        addFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Friends.this, AddFriend.class);
                startActivity(i);
            }
        });
        setSupportActionBar((Toolbar) findViewById(R.id.my_toolbar));
        setTitle("Friends");
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = new StringBuilder()
                .append("http://proj309-mg-01.misc.iastate.edu:8080/users/")
                .append(User.getCurrentUser().getId())
                .append("/friends")
                .toString();

        Log.d("Array Request", url);


        JsonArrayRequest request = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.d("Response", response.toString());
                        User.getCurrentUser().getFriends().clear();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                Log.d("postFromJSON", String.valueOf(i));
                                User.getCurrentUser().getFriends().add(User.fromJson(response.getJSONObject(i)));
                                adapter.notifyDataSetChanged();
                                Log.d("Adapter size: ", String.valueOf(adapter.getItemCount()));


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Error " + error.getMessage());
                        error.printStackTrace();
                    }
                }

        );
        queue.add(request);
        initRecyclerView();

    }


    /**
     * Initializes RecyclerView
     */
    private void initRecyclerView() {
        Log.d(TAG, "initRecyclerView called");
        recyclerView = findViewById(R.id.friends_recyclerview);
        adapter = new FriendsAdapter(this, User.getCurrentUser().getFriends(), false);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
    }

}
