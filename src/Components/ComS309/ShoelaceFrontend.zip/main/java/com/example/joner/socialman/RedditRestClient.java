package com.example.joner.socialman;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.PrecomputedText;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.message.BasicHeader;
import okhttp3.FormBody;
import okhttp3.Request;
import okhttp3.RequestBody;

import static android.content.Context.MODE_PRIVATE;
import static com.facebook.FacebookSdk.getApplicationContext;

/**
 * This is the class that RedditLogin uses to retrieve the Reddit access token,
 * Reddit username, and the Reddit posts. This class is also used by the CreatePost class
 * to submit a post to the user's subreddit
 */
public class RedditRestClient {


    SharedPreferences pref;
    String token;
    Context context;
    private static String CLIENT_ID = "WU-cmrRk2rHzWQ";
    private static String CLIENT_SECRET ="";
    private static final String BASE_URL = "https://www.reddit.com/api/v1/";
    private static String REDIRECT_URI="http://localhost";
    private SharedPreferences.Editor editor;


    RedditRestClient(Context cnt){
        context = cnt;
        editor = context.getSharedPreferences("Reddit_Info", MODE_PRIVATE).edit();
    }
    private static AsyncHttpClient client = new AsyncHttpClient();

    public static void get(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.get(getAbsoluteUrl(url), params, responseHandler);
    }

    public static void post(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {

        Variables.getInstance().getRedditClient().post(getAbsoluteUrl(url), params, responseHandler);
    }

    private static String getAbsoluteUrl(String relativeUrl) {
        return BASE_URL + relativeUrl;
    }

    /**
     * This method makes an HTTP request to the Reddit API for an access token with the permissions
     * specified in the given url. The access token is active for one hour
     * @param relativeUrl
     * @param grant_type
     * @param device_id
     * @throws JSONException
     */
    public void getToken(String relativeUrl,String grant_type,String device_id) throws JSONException {
        Variables.getInstance().getRedditClient().setBasicAuth(CLIENT_ID,CLIENT_SECRET);
        pref = context.getSharedPreferences("AppPref", MODE_PRIVATE);
        String code =pref.getString("Code", "");

        RequestParams requestParams = new RequestParams();
        requestParams.put("code",code);
        requestParams.put("grant_type",grant_type);
        requestParams.put("redirect_uri", REDIRECT_URI);

        post(relativeUrl, requestParams, new JsonHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                Log.i("Reddit_response",response.toString());
                Variables.getInstance().setLoggedInReddit(true);
                try {
                    token = response.getString("access_token").toString();
                    Variables.getInstance().setRedditAccessToken(token);

                    editor.putString("token", token);
                    editor.apply();

                    getPosts(token);
                    getUsername();

                }catch (JSONException j)
                {
                    j.printStackTrace();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                //super.onFailure(statusCode, headers, throwable, errorResponse);
                Log.i("statusCode", "" + statusCode);
            }
        });
    }

    /**
     * This method is called after the access token is acquired. It will also use an HTTP get request to
     * get the posts from the user's home timeline of post on Reddit. The posts are then stored in the
     * Variables class
     * @param token
     */
    public void getPosts(String token) {

        Header[] headers = new Header[2];
        headers[0] = new BasicHeader("User-Agent", "ComS309");
        headers[1] = new BasicHeader("Authorization", "bearer " + token);

        Variables.getInstance().getRedditClient().get(context, "https://oauth.reddit.com/best", headers, null, new JsonHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                Log.i("Reddit_response_success", response.toString());
                Variables.getInstance().getRedditPosts().clear();
                try {
                    JSONObject data = response.getJSONObject("data");
                    JSONArray children = data.getJSONArray("children");
                    for(int i = 0; i < children.length(); i++){
                        String title;
                        String name;
                        String imgURL = "";
                        JSONObject post = children.getJSONObject(i);
                        JSONObject postData = post.getJSONObject("data");
                        title = postData.getString("title");
                        name = postData.getString("subreddit_name_prefixed");
                        if(postData.has("url")){
                            imgURL = postData.getString("url");
                        }
                        Variables.getInstance().addRedditPost(new Post.PostBuilder()
                                .addSource("Reddit")
                                .addDescription(title)
                                .addImageURL(imgURL)
                                .addName(name)
                                .addTimePosted("N/A")
                                .build());
                    }
                    
                } catch (JSONException j) {
                    j.printStackTrace();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                Log.i("Reddit_response_failure", errorResponse.toString());
                Log.i("statusCode", "" + statusCode);
            }
        });
    }

    /**
     * This method is used to get the username of the Reddit account signed in. It is necessary in order to
     * submit a post to the user's subreddit.
     */
    private void getUsername(){
        Header[] headers = new Header[2];
        headers[0] = new BasicHeader("User-Agent", "ComS309");
        headers[1] = new BasicHeader("Authorization", "bearer " + token);

        Variables.getInstance().getRedditClient().get(context, "https://oauth.reddit.com/api/v1/me", headers, null, new JsonHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                Log.i("Reddit_response_success", response.toString());
                try {
                    String name = response.getString("name");

                    editor.putString("username", name);
                    editor.apply();

                    Variables.getInstance().setRedditUsername(name);
                } catch (JSONException j) {
                    j.printStackTrace();
                }
            }
            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                Log.i("Reddit_response_failure", errorResponse.toString());
                Log.i("statusCode", "" + statusCode);
            }
        });
    }

    /**
     * Method will use an HTTP post request to submit a post to the user's subreddit. The post
     * contains a title and an image url
     * @param token
     * @param title
     * @param progressBar
     */
    public void submitPost(final String token, String title, final ProgressBar progressBar, String imageURL){
        String url = "https://oauth.reddit.com/api/submit.json";

        RequestParams requestParams = new RequestParams();
        requestParams.put("sr", "u_" + Variables.getInstance().getRedditUsername());
        requestParams.put("kind", "image");
        requestParams.put("title", title);
        requestParams.put("api_type", "json");
        requestParams.put("url", imageURL);

        Header[] headers = new Header[3];
        headers[0] = new BasicHeader("Authorization", "bearer " + token);
        headers[1] = new BasicHeader("Content-Type", "application/x-www-form-urlencoded");
        headers[2] = new BasicHeader("User-Agent", "ComS309");

        Variables.getInstance().getRedditClient().post(getApplicationContext(), url, headers, requestParams, "json", new JsonHttpResponseHandler(){
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                Log.i("Reddit_submit_response",response.toString());
                progressBar.setVisibility(View.INVISIBLE);
                Toast.makeText(getApplicationContext(), "Posted to Reddit!", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                super.onFailure(statusCode, headers, throwable, errorResponse);
                Log.i("statusCode", "" + statusCode);
                progressBar.setVisibility(View.INVISIBLE);
                Toast.makeText(getApplicationContext(), "Reddit shit a brick", Toast.LENGTH_LONG).show();
            }
        });

    }


}