package com.example.joner.socialman;


import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.facebook.AccessToken;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.twitter.sdk.android.core.TwitterSession;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft;
import org.java_websocket.drafts.Draft_6455;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

/**
 * Global variables
 */
public class Variables {

    //TODO Converting to singleton class and add getters/setters for this values and update usages.

    private static Variables instance = null;

    private ArrayList<User> friends = new ArrayList<>();
    public ArrayList<User> getFriends(){
        return friends;
    }

    private ArrayList<ArrayList<Post>> chats = new ArrayList<ArrayList<Post>>();
    public ArrayList<ArrayList<Post>> getChats() {
        return chats;
    }
    public void setChats(ArrayList<ArrayList<Post>> chats){
        this.chats = chats;
    }

    public static int currentChatNumber;
    public static String currentChatName = "";

    private Context context;

    /**
     * Gets stored context
     * @return context
     */
    public Context getContext(){
        return context;
    }

    /**
     * Sets stored context
     * @param context
     */
    public void setContext(Context context){
        this.context = context;
    }


    public static RecyclerView ChatRecycler;
    private WebSocketClient cc;

    /**
     * Gets the main websocket
     * @return main websocket
     */
    public WebSocketClient getWebSocketClient() {
        return cc;
    }
    private int notificationChannel = 0;
    public void connectWebSocket(){
        Draft[] drafts = {new Draft_6455()};
        String w = "ws://proj309-mg-01.misc.iastate.edu:8080/websocket/" + User.getCurrentUser().getName();

        try {
            Log.d("Socket:", "Trying socket");

            cc = new WebSocketClient(new URI(w), drafts[0]) {
                @Override
                public void onMessage(String message) {
                    Log.d("socket_message:", "run() returned: " + message);

                    message = message.substring(5);
                    Post post = new Post.PostBuilder()
                            .addName("")
                            .addSource("")
                            .addDescription(message)
                            .addImageURL("")
                            .addTimePosted(Util.getCurTimeString())
                            .build();
                    Variables.getInstance().getChats().get(Variables.currentChatNumber).add(post);
                    chatAdapter.notifyDataSetChanged();
                    Variables.ChatRecycler.smoothScrollToPosition(Variables.getInstance().getChats().get(Variables.currentChatNumber).size());

                    if(!message.contains("@" + currentChatName + " ")){
                        notificationChannel++;
                        createNotificationChannel();
                        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(Variables.getInstance().getContext(), "1")
                                .setSmallIcon(R.drawable.messenger_bubble_small_blue)
                                .setContentTitle("Shoestring")
                                .setContentText(message)
                                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
                        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(Variables.getInstance().getContext());
                        notificationManager.notify(notificationChannel, mBuilder.build());
                    }
                }

                @Override
                public void onOpen(ServerHandshake handshake) {
                    Log.d("OPENsocket", "run() returned: " + "is connecting");
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    Log.d("CLOSEsocket", "onClose() returned: " + reason);
                }

                @Override
                public void onError(Exception e) {
                    Log.d("SocketException:", e.toString());
                }
            };

        } catch (URISyntaxException e) {
            Log.d("URISyntaxException:", e.getMessage().toString());
            e.printStackTrace();
        }
        cc.connect();
    }


    private ArrayList<Post> FeedPosts = new ArrayList<>();

    private AccessToken token;

    /**
     * Get current Facebook AccessToken
     * @return current token
     */
    public AccessToken getFBAccessToken(){
        return token;
    }

    /**
     * Set the facebook AccessToken
     * @param token
     */
    public void setFBAccessToken(AccessToken token){
        this.token = token;
    }

    private TwitterSession session;

    /**
     * Get the current TwitterSession
     * @return current session
     */
    public TwitterSession getTwitterSession(){
        return session;
    }

    /**
     * Set the current TwitterSession
     * @param session
     */
    public void setTwitterSession(TwitterSession session){
        this.session = session;
    }

    private String redditAccessToken = "";

    /**
     * Get the current Reddit access token
     * @return current token
     */
    public String getRedditAccessToken(){
        return redditAccessToken;
    }

    /**
     * Set the Reddit access token
     * @param token
     */
    public void setRedditAccessToken(String token){
        this.redditAccessToken = token;
    }
    private  String redditUsername = "";

    /**
     * Returns reddit username
     * @return reddit username
     */
    public String getRedditUsername(){
        return redditUsername;
    }

    /**
     * Sets reddit username
     * @param name
     */
    public void setRedditUsername(String name){
        this.redditUsername = name;
    }

    private AsyncHttpClient RedditClient = new AsyncHttpClient();

    /**
     * Returns reddit HTTP client
     * @return client
     */
    public AsyncHttpClient getRedditClient(){
        return RedditClient;
    }

    private ArrayList<Post> FBposts = new ArrayList<>();
    private ArrayList<Post> TwitterPosts = new ArrayList<>();
    private ArrayList<Post> RedditPosts = new ArrayList<>();


    private boolean isLoggedInFacebook = false;
    private boolean isLoggedInTwitter = false;
    private boolean isLoggedInReddit = false;

    private boolean manualLogout = false;

    /**
     * Gets manual logout boolean
     * @return manual logout
     */
    public boolean getManualLogout(){
        return manualLogout;
    }

    /**
     * Sets manual logout boolean
     * @param l
     */
    public void setManualLogout(boolean l){
        manualLogout = l;
    }

    private ChatAdapter chatAdapter;
    private MyAdapter postAdapter;

    /**
     * Get array of Facebook posts
     * @return facebook posts
     */
    public ArrayList<Post> getPostsFB() {
        return FBposts;
    }

    /**
     * Adds a Facebook post to array
     * @param post
     */
    public void addFBPost(Post post) {
        FBposts.add(post);
    }

    /**
     * Get array of Twitter posts
     * @return twitter posts
     */
    public ArrayList<Post> getPostsTwitter() {
        return TwitterPosts;
    }

    /**
     * Adds a Twitter post to array
     * @param post
     */
    public void addTwitterPost(Post post) {
        TwitterPosts.add(post);
    }

    /**
     * Gets array of Reddit posts
     * @return arraylist of posts
     */
    public ArrayList<Post> getRedditPosts() {
        return RedditPosts;
    }

    /**
     * Adds a Reddit post to array
     * @param post
     */
    public void addRedditPost(Post post) {
        RedditPosts.add(post);
    }

    /**
     * Gets array of Feed Posts
     * @return feed posts
     */
    public ArrayList<Post> getFeedPosts(){
        return FeedPosts;
    }

    private ArrayList<Post> appPosts;


    /**
     * Gets array of AppPosts
     * @return app posts
     */
    public ArrayList<Post> getAppPosts() {
        return appPosts;
    }


    public void setAppPosts(ArrayList<Post> appPosts) {
        this.appPosts = (ArrayList<Post>) appPosts.clone();
    }

    /**
     * Private Variables constructor
     */
    private Variables() {
        appPosts = new ArrayList<>();
        TwitterPosts = new ArrayList<>();
        FBposts = new ArrayList<>();
    }

    /**
     * Gets current Variables instance
     * @return instance
     */
    public static Variables getInstance() {
        if (instance == null)
            instance = new Variables();
        return instance;

    }

    /**
     * Clears ArrayLists
     */
    public void reset() {
        FBposts.clear();
        TwitterPosts.clear();
        RedditPosts.clear();
        appPosts.clear();
    }

    /**
     * Sets login status of Facebook
     * @param loggedInFacebook
     */
    public void setLoggedInFacebook(boolean loggedInFacebook) {
        this.isLoggedInFacebook = loggedInFacebook;
    }

    /**
     * Gets login status of Facebook
     * @return status
     */
    public boolean getLoggedInFacebook() {
        return isLoggedInFacebook;
    }

    /**
     * Sets login status of Twitter
     * @param loggedInTwitter
     */
    public void setLoggedInTwitter(boolean loggedInTwitter) {
        this.isLoggedInTwitter = loggedInTwitter;
    }

    /**
     * Gets login status of Twitter
     * @return status
     */
    public boolean getLoggedInTwitter() {
        return isLoggedInTwitter;
    }

    /**
     * Sets login status of Reddit
     * @param loggedInReddit
     */
    public void setLoggedInReddit(boolean loggedInReddit) {
        this.isLoggedInReddit = loggedInReddit;
    }

    /**
     * Gets login status of Reddit
     * @return status
     */
    public boolean getLoggedInReddit() {
        return isLoggedInReddit;
    }

    /**
     * Sets chat adapter
     * @param adapter
     */
    public void setChatAdapter(ChatAdapter adapter) {
        chatAdapter = adapter;
    }

    /**
     * Returns current chat adapter
     * @return current adapter
     */
    public ChatAdapter getChatAdapter() {
        return chatAdapter;
    }

    /**
     * Sets main feed adapter
     * @param adapter
     */
    public void setAdapter(MyAdapter adapter){
        this.postAdapter = adapter;
    }

    /**
     * Gets the postAdapter
     * @return current postAdapter
     */
    public MyAdapter getPostAdapter(){
        return postAdapter;
    }

    /**
     * Creates a notification channel
     */
    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = Variables.getInstance().getContext().getString(R.string.channel_name);
            String description = Variables.getInstance().getContext().getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("1", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = Variables.getInstance().getContext().getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}

