package com.example.joner.socialman;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.widget.ShareDialog;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.tweetcomposer.ComposerActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.message.BasicHeader;
import retrofit2.http.Multipart;

/**
 * Activity for creating a post
 */
public class CreatePost extends Activity {

    private String TAG = "CreatePost";
    private Button share;
    private EditText description;
    private Button pickImage;
    private ImageView imageView;
    private ProgressBar progressBar;
    private CheckBox checkBoxButton;
    private CheckBox twitterCheckBox;
    private CheckBox redditCheckBox;
    private BottomNavigationView navigation;
    private Bitmap bitmap = null;
    private Post post;
    private Uri uri;
    private String extension;
    private String url;



    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.navHome:
                    Intent i = new Intent(CreatePost.this, MainActivity.class);
                    startActivity(i);
                    return true;
                case R.id.createPost:
                    return true;
                case R.id.account:
                    i = new Intent(CreatePost.this, AccountSettings.class);
                    startActivity(i);
                    return true;
            }
            return false;
        }
    };

    private int PICK_IMAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_post);
        findViews();

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        navigation.setSelectedItemId(R.id.createPost);
        progressBar.setVisibility(View.INVISIBLE);


        pickImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, PICK_IMAGE);
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (description.getText().length() == 0) {
                    Toast t = Toast.makeText(getApplicationContext(), "Description cannot be blank", Toast.LENGTH_SHORT);
                    t.show();
                    return;
                }
                sendImage();

            }
        });
    }

    /**
     * Send post to Facebook
     */
    private void postToFacebook() {

        Log.d(TAG, "postToFacebook called");
        SharePhoto photo;
        SharePhotoContent content;
        ShareDialog sd = new ShareDialog(this);
        if (bitmap != null) {
            photo = new SharePhoto.Builder()
                    .setBitmap(bitmap)
                    .build();
            content = new SharePhotoContent.Builder()
                    .addPhoto(photo)
                    .build();
            sd.show(content);
        }
    }

    /**
     * Send post to twitter
     */
    private void postToTwitter(String imageURL) {
        if(Variables.getInstance().getTwitterSession() != null){
            final TwitterSession session = TwitterCore.getInstance().getSessionManager().getActiveSession();
            Log.d("TwitterSession", session.getUserName());
            final Intent intent = new ComposerActivity.Builder(CreatePost.this)
                    .session(session)
                    .text(description.getText().toString() + "\n" + imageURL)
                    .darkTheme()
                    .createIntent();
            startActivity(intent);
        }
    }


    /**
     * Send post to Reddit
     */
    private void postToReddit(String url){
        progressBar.setVisibility(View.VISIBLE);
        RedditRestClient client = new RedditRestClient(getApplicationContext());
        client.submitPost(Variables.getInstance().getRedditAccessToken(), description.getText().toString(), progressBar, url);
    }

    /**
     * Send post to our database
     */
    private void postToDB() {
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url = new StringBuilder()
                .append("http://proj309-mg-01.misc.iastate.edu:8080/users/")
                .append(User.getCurrentUser().getId())
                .append("/newpost")
                .toString();
        Log.d(TAG, "Sending post to: " + url);
        JSONObject payload = null;
        try {
            payload = new JSONObject()
                    .put("description", post.getDescription())
                    .put("timeposted", post.getTimePosted())
                    .put("imageURL", post.getImageURL());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.d("JSON Payload:", payload.toString());


        JsonObjectRequest postRequest = new JsonObjectRequest(url, payload,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Variables.getInstance().getAppPosts().add(post);
                        Log.d("Post Response", response.toString());

                        Util.fetchPostsFromDB(getApplicationContext());
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Error " + error.getMessage());
                        Toast t = Toast.makeText(getApplicationContext(), "Server Error, check log", Toast.LENGTH_SHORT);
                        t.show();
                    }
                }
        );
        queue.add(postRequest);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedImage = data.getData();

            String[] filePathColumn = {MediaStore.MediaColumns.DATA};
            Cursor cursor =  getContentResolver().query(selectedImage, filePathColumn, null, null, null);
            if (cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                String filePath = cursor.getString(columnIndex);
                extension = filePath.substring(filePath.lastIndexOf(".") + 1);
            }

            try {
                Log.d("image uri", selectedImage.toString());
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImage);
                imageView.setImageBitmap(bitmap);
                imageView.setVisibility(View.VISIBLE);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Finds views
     */
    private void findViews() {
        imageView = findViewById(R.id.imageView);
        navigation = findViewById(R.id.navigation);
        checkBoxButton = findViewById(R.id.post_to_facebook_toggle);
        twitterCheckBox = findViewById(R.id.post_to_twitter_toggle);
        redditCheckBox = findViewById(R.id.post_to_reddit_toggle);
        share = findViewById(R.id.share_button);
        description = findViewById(R.id.description);
        progressBar = findViewById(R.id.progressBar);
        pickImage = findViewById(R.id.imageSelect);
    }

    private void sendImage(){
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        HashMap<String, String> params = new HashMap<String, String>();
        String urlImage = "http://proj309-mg-01.misc.iastate.edu:8080/" + extension;
//        String urlImage = "http://10.27.193.170:8080/" + extension;

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        if (extension.equalsIgnoreCase("jpg"))
            extension = "JPEG";
        Bitmap.CompressFormat format = Bitmap.CompressFormat.valueOf(extension);
        bitmap.compress(format, 90, stream);

        final byte[] byteArray = stream.toByteArray();


        StringRequest postRequest = new StringRequest(Request.Method.POST, urlImage, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Display the first 500 characters of the response string.
//                mTextView.setText("Response is: "+ response.substring(0,500));
                Log.d("Post Response", response);
                post = new Post.PostBuilder()
                        .addName(User.getCurrentUser().getName())
                        .addSource(getString(R.string.app_name))
                        .addDescription(description.getText().toString())
                        .addImageURL(response)
                        .addTimePosted(Util.getCurTimeString())
                        .build();
                url = response;
                postToDB();

                if (redditCheckBox.isChecked()){
                    postToReddit(response);
                }
                if (twitterCheckBox.isChecked()) {
                    postToTwitter(response);
                }
                if (checkBoxButton.isChecked()) {
                    postToFacebook();
                }

                // save to db in Post
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG, "Error_Sending_Image" + error.getMessage());
                //Toast t = Toast.makeText(getApplicationContext(), "Server Error, check log", Toast.LENGTH_SHORT);
                //t.show();
            }
        }){
            @Override
            public byte[] getBody() throws AuthFailureError {
                Log.d("byteArray", byteArray.toString());
                return byteArray;
            }

            @Override
            public String getBodyContentType() {
                return "text/plain";
            }
        };

        queue.add(postRequest);
    }
}
