package com.example.joner.socialman;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A class to model app User
 */
public class User {
    private int id;
    private String name;
    private String email;
    private String password;
    private static User currentUser;
    private String imageURL;
    private ArrayList<User> friends = new ArrayList<>();


    @Override
    public boolean equals(Object obj) {
        if(obj == null)
            return false;
        if(!(obj instanceof User))
            return false;
        if(((User) obj).id != this.id)
            return false;
        return true;
    }

    /**
     * Get the friends for current User
     * @return list of friends
     */
    public ArrayList<User> getFriends() {
        return friends;
    }

    /**
     * Set friends ArrayList
     * @param friends
     */
    public void setFriends(ArrayList<User> friends) {
        this.friends = friends;
    }

    /**
     * Convert JSONObject to User
     * @param jsonObject User
     * @return user from json
     */
    public static User fromJson(JSONObject jsonObject) {
        User user = new User();
        try {
            user.id = jsonObject.getInt("id");
            user.name = jsonObject.getString("name");
            user.email = jsonObject.getString("email");
            user.password = jsonObject.getString("password");
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return user;
    }

    /**
     * Get image URL for User
     * @return image url
     */
    public String getImageURL() {
        return imageURL;
    }

    /**
     * Set image URL for User
     * @param imageURL
     */
    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    /**
     * Get the currently logged in User
     * @return current user
     */
    public static User getCurrentUser() {
        return currentUser;
    }

    /**
     * Set the currently logged in User
     * @param currentUser
     */
    public static void setCurrentUser(User currentUser) {
        User.currentUser = currentUser;
    }

    /**
     * Get ID from User
     * @return user id
     */
    public int getId() {
        return id;
    }

    /**
     * Set ID from User
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Get name from User
     * @return user name
     */
    public String getName() {
        return name;
    }

    /**
     * Set name for User
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Get email for User
     * @return user email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set email for User
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Get password for User
     * @return user password
     */
    public String getPassword() {
        return password;
    }
    /**
     * Set password for User
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
