package com.example.joner.socialman;

import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.DefaultLogger;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterApiClient;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterConfig;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.core.models.Tweet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.message.BasicHeader;
import retrofit2.Call;

import static com.facebook.FacebookSdk.getApplicationContext;

/**
 * This class is used by the WelcomeActivity and the MainActivity to reload the social media data
 * from Facebook, Twitter and Reddit
 */
public class Refresh {

    public Refresh(){ }

    /**
     * Makes a graph request to Facebook, similar to that of FacebookLogin. It gets the user's post data
     * and stores it in the Variables class
     * @param token
     * @param fromStartup
     */
    public void graphRequest(AccessToken token, final Boolean fromStartup){
        if(token != null){
            if(!token.isExpired()){
                Variables.getInstance().setLoggedInFacebook(true);
                new GraphRequest(
                        token,
                        "/me?fields=posts,photos,first_name,last_name",
                        null,
                        HttpMethod.GET,
                        new GraphRequest.Callback() {
                            public void onCompleted(GraphResponse response) {
                                try {
                                    Variables.getInstance().getPostsFB().clear();
                                    JSONObject object = response.getJSONObject();
                                    String userId;
                                    URL profilePicture = null;
                                    if(object.has("id")){
                                        userId = object.getString("id");
                                        profilePicture = new URL("https://graph.facebook.com/" + userId + "/picture?width=500&height=500");
                                    }
                                    String firstName = "";
                                    String lastName = "";
                                    if (object.has("first_name"))
                                        firstName = object.getString("first_name");
                                    if (object.has("last_name"))
                                        lastName = object.getString("last_name");
                                    if (object.has("posts")) {
                                        JSONObject user_posts = object.getJSONObject("posts");
                                        JSONArray a = user_posts.getJSONArray("data");
                                        for (int i = 0; i < a.length(); i++) {
                                            JSONObject b = a.getJSONObject(i);
                                            if (b.has("message")) {

                                                Post newPost = new Post.PostBuilder()
                                                        .addName(firstName + " " + lastName)
                                                        .addSource("Facebook")
                                                        .addDescription(b.getString("message"))
                                                        .addImageURL(profilePicture.toString())
                                                        .addTimePosted("N/A")
                                                        .build();
                                                Variables.getInstance().addFBPost(newPost);

                                            }
                                        }
                                    }
                                    if(fromStartup){
                                        Intent i = new Intent(getApplicationContext(), MainActivity.class);
                                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        getApplicationContext().startActivity(i);
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                } catch (MalformedURLException e) {
                                    e.printStackTrace();
                                } catch (NullPointerException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                ).executeAsync();
            }
            else{
                Variables.getInstance().setLoggedInFacebook(false);
            }
        }

    }

    /**
     * Makes a Twitter API request similar to the TwitterLogin and gets the user's timeline posts and
     * stores them in the Variables class.
     * @param session
     * @param fromStartup
     */
    public void getTweets(TwitterSession session, final Boolean fromStartup) {
        if(session != null){
            if(!session.getAuthToken().isExpired()){
                Variables.getInstance().setLoggedInTwitter(true);
                TwitterConfig config = new TwitterConfig.Builder(getApplicationContext())
                        .logger(new DefaultLogger(Log.DEBUG))
                        .twitterAuthConfig(new TwitterAuthConfig("Mra5cn6PbohYlevMYtpIxoLnI", "4PHG0u6MU7D0qRduKwh9sa61uLceODLWf2ZTXcKZvALToZGG5r"))
                        .debug(true)
                        .build();
                Twitter.initialize(config);

                TwitterApiClient client = TwitterCore.getInstance().getApiClient(session);
                Call<List<Tweet>> call = client.getStatusesService().homeTimeline(200, null, null, false, false, true, true);
                call.enqueue(new Callback<List<Tweet>>() {
                    @Override
                    public void success(Result<List<Tweet>> result) {
                        Variables.getInstance().getPostsTwitter().clear();
                        List<Tweet> tweets = result.data;
                        Log.d("Twitter Data", result.data.toString());

                        for (int i = 0; i < tweets.size(); i++) {
                            Tweet tweet = tweets.get(i);
                            String caption = tweet.text;
                            String source = tweet.user.name;
                            String imageURL = tweet.user.profileImageUrl;
                            String time = tweet.createdAt;


                            Variables.getInstance().addTwitterPost(new Post.PostBuilder()
                                    .addSource("Twitter")
                                    .addDescription(caption)
                                    .addImageURL(imageURL)
                                    .addName(source)
                                    .addTimePosted(time)
                                    .build());
                        }
                        if(fromStartup){
                            Intent i = new Intent(getApplicationContext(), MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            getApplicationContext().startActivity(i);
                        }
                    }

                    @Override
                    public void failure(TwitterException exception) {
                        Log.d("Twitter Failure", exception.toString());
                        Toast.makeText(getApplicationContext(), "Failed to authenticate. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
            else{
                Variables.getInstance().setLoggedInTwitter(false);
            }
        }
    }

    /**
     * Makes an API call to Reddit similar to that in RedditRestClient and get the users timeline posts
     * and store thme in the Variables class.
     * @param token
     * @param fromStartup
     */
    public void RedditPosts(String token, final Boolean fromStartup){
        if(token != null){
            AsyncHttpClient client = new AsyncHttpClient();
            client.setBasicAuth("WU-cmrRk2rHzWQ","");
            Header[] headers = new Header[2];
            headers[0] = new BasicHeader("User-Agent", "ComS309");
            headers[1] = new BasicHeader("Authorization", "bearer " + token);

            client.get(getApplicationContext(), "https://oauth.reddit.com/best", headers, null, new JsonHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    Log.i("Reddit_response_success", response.toString());
                    Variables.getInstance().getRedditPosts().clear();
                    Variables.getInstance().setLoggedInReddit(true);
                    try {
                        JSONObject data = response.getJSONObject("data");
                        JSONArray children = data.getJSONArray("children");
                        for(int i = 0; i < children.length(); i++){
                            String title;
                            String name;
                            String imgURL = "";
                            JSONObject post = children.getJSONObject(i);
                            JSONObject postData = post.getJSONObject("data");
                            title = postData.getString("title");
                            name = postData.getString("subreddit_name_prefixed");
                            if(postData.has("url")){
                                imgURL = postData.getString("url");
                            }
                            Variables.getInstance().addRedditPost(new Post.PostBuilder()
                                    .addSource("Reddit")
                                    .addDescription(title)
                                    .addImageURL(imgURL)
                                    .addName(name)
                                    .addTimePosted("N/A")
                                    .build());
                        }
                        if(fromStartup){
                            Intent i = new Intent(getApplicationContext(), MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            getApplicationContext().startActivity(i);
                        }

                    } catch (JSONException j) {
                        j.printStackTrace();
                    }

                }

                @Override
                public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                    //Log.i("Reddit_response_failure", errorResponse.toString());
                    //Log.i("statusCode", "" + statusCode);
                }
            });
        }
        else{
            Variables.getInstance().setLoggedInReddit(false);
        }

    }
}