package com.example.joner.socialman;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
/**
 * Adapter for main feed
 */
public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    @NonNull
    private static final String TAG = "MyAdapter";
    private ArrayList<Post> posts;
    private Context mContext;

    /**
     * Constructs a new MyAdapter
     * @param c Context
     * @param posts ArrayList of Post
     */
    public MyAdapter(@NonNull Context c, ArrayList<Post> posts) {
        this.mContext = c;
        this.posts = posts;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        if(posts.get(i).getImageURL() == null) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_post2, viewGroup, false);
            ViewHolder holder = new ViewHolder(view);
            return holder;
        }
        else {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_post, viewGroup, false);
            ViewHolder holder = new ViewHolder(view);
            return holder;
        }
    }


    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        Log.d(TAG, "OnBindViewHolder: called");

        if(viewHolder.image != null) {
            //Load and set image
            Glide.with(mContext)
                    .asBitmap()
                    .load(posts.get(i).getImageURL())
                    .into(viewHolder.image);
        }

        //String url = posts.get(i).getImageURL();
        //if(url.substring(url.length() - 3))

        //Set description
        viewHolder.description.setText(posts.get(i).getDescription());
        ViewGroup.LayoutParams params = viewHolder.description.getLayoutParams();
        params.width = 500;
        viewHolder.description.setLayoutParams(params);

        //Set name
        viewHolder.name.setText(posts.get(i).getName());
        //Set source
        viewHolder.source.setText(posts.get(i).getSource());
        //Create onClickListener
        viewHolder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: clicked on: " + posts.get(i).getName());
                Intent intent = new Intent(mContext, PostDetails.class);
                intent.putExtra("post", posts.get(i));
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    /**
     * ViewHolder for Post
     */
    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView name;
        TextView description;
        RelativeLayout parentLayout;
        TextView source;


        public ViewHolder(View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.post_image);
            name = itemView.findViewById(R.id.post_name);
            description = itemView.findViewById(R.id.description);
            parentLayout = itemView.findViewById(R.id.parent_layout);
            source = itemView.findViewById(R.id.post_source);
        }
    }

}
