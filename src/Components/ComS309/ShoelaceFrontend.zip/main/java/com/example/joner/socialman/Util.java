package com.example.joner.socialman;


import android.content.Context;
import android.icu.util.Calendar;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import retrofit2.http.HEAD;

/**
 * Utility class
 */
public class Util {

    private static String TAG = "Util";

    /**
     * Get the current time string.
     * @return Current time as string
     */
    public static String getCurTimeString() {
        Date currentTime = Calendar.getInstance().getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
        return sdf.format(currentTime);

    }

    /**
     * Fetches posts for current user.
     * @param c current application context.
     */
    public static void fetchPostsFromDB(Context c) {
        RequestQueue queue = Volley.newRequestQueue(c);
        String url = new StringBuilder()
                .append("http://proj309-mg-01.misc.iastate.edu:8080/users/")
                .append(User.getCurrentUser().getId())
                .append("/posts")
                .toString();

        Log.d("Array Request", url);
        JsonArrayRequest request = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.d("Response", response.toString());
                        postsFromJSON(response);
                        Log.d("DB posts", response.toString());

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Error " + error.getMessage());
                        error.printStackTrace();
                    }
                }

        );


        queue.add(request);
    }

    /**
     * Convert JSONArray to array of Post and stores in variables.
     * @param response the response to process
     */
    public static void postsFromJSON(JSONArray response) {
        Variables.getInstance().getAppPosts().clear();
        Log.d("Response.length()", "" + response.length());
        for (int i = response.length() - 1; i >= 0; i--) {
            try {
                Log.d("postFromJSON", String.valueOf(i));
                Variables.getInstance().getAppPosts().add(Post.fromDB(response.getJSONObject(i)));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        //Variables.getInstance().getAdapter().notifyDataSetChanged();

        Log.d(TAG, "postsFromJSON: " + Variables.getInstance().getAppPosts().size());
    }

}