package com.example.joner.socialman;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

/**
 * Model of post
 */
public class Post implements Serializable {
    private String name;
    private String source;
    private String description;
    private String imageURL;
    private String timePosted;

    /**
     * Converts JSON object to Post
     * @param object
     * @return post
     */
    public static Post fromDB(JSONObject object) {
        try {
            return new PostBuilder()
                    .addName(User.getCurrentUser().getName())
                    .addDescription(object.getString("description"))
                    .addImageURL(object.getString("imageURL"))
                    .addSource("Social Man")
                    .addTimePosted(object.getString("timeposted"))
                    .build();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    protected Post(String name, String source, String description, String imageURL, String timePosted) {
        this.name = name;
        this.source = source;
        this.description = description;
        this.imageURL = imageURL;
        this.timePosted = timePosted;
    }

    /**
     * Gets time posted
     * @return time posted
     */
    public String getTimePosted() {
        return timePosted;
    }

    /**
     * Get the post author
     * @return author
     */
    public String getName() {
        return name;
    }

    /**
     * Get post source
     * @return source
     */
    public String getSource() {
        return source;
    }

    /**
     * Get post description
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Get post image URL
     * @return image URL
     */
    public String getImageURL() {
        return imageURL;
    }

    /**
     * Builder class for Post
     */
    public static class PostBuilder {

        private String name = null;
        private String source = null;
        private String description = null;
        private String imageURL = null;
        private String timePosted = null;

        public PostBuilder addName(String name) {
            this.name = name;
            return this;
        }

        public PostBuilder addSource(String source) {
            this.source = source;
            return this;
        }

        public PostBuilder addDescription(String description) {
            this.description = description;
            return this;
        }

        public PostBuilder addImageURL(String imageURL) {
            this.imageURL = imageURL;
            return this;
        }

        public PostBuilder addTimePosted(String timePosted) {
            this.timePosted = timePosted;
            return this;
        }

        public Post build() {
            if (name == null)
                throw new IllegalStateException("No name provided");
            if (source == null)
                throw new IllegalStateException("No source provided");
            if (description == null)
                throw new IllegalStateException("No description provided");

//            if (imageURL == null)
//                throw new IllegalStateException("No imageURL provided");
//
            if (timePosted == null)
                throw new IllegalStateException("No timePosted provided");
            return new Post(
                    name,
                    source,
                    description,
                    imageURL,
                    timePosted
            );

        }
    }

}
