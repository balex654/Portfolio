package com.example.joner.socialman;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.AccessToken;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.google.gson.Gson;
import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.DefaultLogger;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterApiClient;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterConfig;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.core.models.Tweet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;

import static com.facebook.FacebookSdk.getApplicationContext;

/**
 * First activity that the user sees when opening the app. The user can select "login", "create account"
 * or the user is logged in automatically if they have logged in before.
 */
public class WelcomeActivity extends AppCompatActivity {

    private boolean isLoggedInFacebook = false;
    private String email = null;
    private String password = null;
    private String TAG = "AppLogin";
    private AccessToken token = null;
    private String RedditToken;
    private boolean success = false;
    private TwitterSession session = null;
    private Refresh r = new Refresh();
    private boolean socialMedia = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Button login = findViewById(R.id.loginWelcome);
        Button create = findViewById(R.id.createAccount);
        ProgressBar progressBar = findViewById(R.id.loginProgress);

        progressBar.setVisibility(View.INVISIBLE);

        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(WelcomeActivity.this, AppLogin.class);
                startActivity(i);
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(WelcomeActivity.this, CreateAccount.class);
                startActivity(i);
            }
        });

        SharedPreferences loginData = getSharedPreferences("login data", MODE_PRIVATE);
        email = loginData.getString("user email", null);
        password = loginData.getString("user password", null);


        SharedPreferences FBloginData = getSharedPreferences("FB login data", MODE_PRIVATE);
        String FBdata = FBloginData.getString("Access token", "");
        Gson gson = new Gson();
        token = gson.fromJson(FBdata, AccessToken.class);
        Variables.getInstance().setFBAccessToken(token);

        SharedPreferences TwitterLoginData = getSharedPreferences("Twitter login data", MODE_PRIVATE);
        String TwitterData = TwitterLoginData.getString("session", "");
        Gson gson2 = new Gson();
        session = gson2.fromJson(TwitterData, TwitterSession.class);
        Variables.getInstance().setTwitterSession(session);

        SharedPreferences RedditLoginData = getSharedPreferences("Reddit_Info", MODE_PRIVATE);
        RedditToken = RedditLoginData.getString("token", "");
        String redditUsername = RedditLoginData.getString("username", "");
        Variables.getInstance().setRedditUsername(redditUsername);
        Variables.getInstance().setRedditAccessToken(RedditToken);
        Log.d("RedditToken", RedditToken);
        Log.d("RedditUsername", redditUsername);

        socialMedia = token != null || session != null || !RedditToken.equals("");

        SharedPreferences ManualLogout = getSharedPreferences("manual logout", MODE_PRIVATE);
        String UserLogout = ManualLogout.getString("logout", "");
        if(!UserLogout.equals("")){
            SharedPreferences.Editor editor1 = getSharedPreferences("FB login data", MODE_PRIVATE).edit();
            editor1.putString("Access token", null);
            editor1.apply();
            SharedPreferences.Editor editor2 = getSharedPreferences("Twitter login data", MODE_PRIVATE).edit();
            editor2.putString("session", null);
            editor2.apply();
            SharedPreferences.Editor editor3 = getSharedPreferences("Reddit_Info", MODE_PRIVATE).edit();
            editor3.putString("token", null);
            editor3.apply();
            token = null;
            session = null;
            RedditToken = null;
            socialMedia = false;
        }

        Log.d("Logging in", String.valueOf(Variables.getInstance().getManualLogout()) + UserLogout);
        if(!Variables.getInstance().getManualLogout() && UserLogout.equals("")){
            if(email != null && password != null){
                Log.d("user_email", email);
                Log.d("user_password", password);

                progressBar.setIndeterminate(true);
                progressBar.setVisibility(View.VISIBLE);
                Applogin(email, password);
            }
        }
    }

    /**
     * Gets specified user from server and logs in to app. Refreshes any social media networks that are signed in.
     * Connects the websocket for direct messaging. Calls the getFriends() method
     * @param email
     * @param password
     */
    private void Applogin(String email, String password){
        final String TAG = "Refresh login";
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url ="http://proj309-mg-01.misc.iastate.edu:8080/checkUser/";

        url = url + email + "/" + password;

        //TODO finish JSON HTTP post request
        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, null,
                new Response.Listener<JSONObject>()
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, "Response from server: " + response.toString());
                        User user = User.fromJson(response);
                        User.setCurrentUser(user);
                        Util.fetchPostsFromDB(getApplicationContext());
                        Variables.getInstance().connectWebSocket();
                        getFriends();
                        Variables.getInstance().setContext(getApplicationContext());

                        r.getTweets(session, true);
                        r.graphRequest(token, true);
                        r.RedditPosts(RedditToken, true);

                        if(!socialMedia){
                            Intent i = new Intent(getApplicationContext(), MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            getApplicationContext().startActivity(i);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Volley error " + error.getMessage());
                        error.printStackTrace();
                    }
                }
        );
        queue.add(postRequest);
    }


    /**
     * Gets a JSON array from the server of all the user's friends and add them
     * to the friends variable in the Variables class
     */
    private void getFriends(){
        String url = "http://proj309-mg-01.misc.iastate.edu:8080/users/";
        url = url + Integer.toString(User.getCurrentUser().getId()) + "/friends";

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());

        JsonArrayRequest request = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.d("Response", response.toString());
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                Variables.getInstance().getFriends().add((User.fromJson(response.getJSONObject(i))));
                                Variables.getInstance().getChats().add(new ArrayList<Post>());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Error " + error.getMessage());
                        error.printStackTrace();
                    }
                }

        );
        queue.add(request);
    }
}
