package com.example.joner.socialman;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONException;

import java.util.UUID;

/**
 * Activity to manage social medias
 */
public class ManageNetworks extends AppCompatActivity {

    private static String CLIENT_ID = "WU-cmrRk2rHzWQ";
    private static String CLIENT_SECRET = "";
    private static String REDIRECT_URI = "http://localhost";
    private static String GRANT_TYPE = "https://oauth.reddit.com/grants/installed_client";
    private static String GRANT_TYPE2 = "authorization_code";
    private static String TOKEN_URL = "access_token";
    private static String OAUTH_URL = "https://www.reddit.com/api/v1/authorize.compact";
    private static String OAUTH_SCOPE = "account";
    private static String DURATION = "permanent";
    private String redditToken;
    private String REDDIT_BASE_URL_OAUTH2 = "https://oauth.reddit.com";

    WebView web;
    SharedPreferences pref;
    Dialog auth_dialog;
    String DEVICE_ID = UUID.randomUUID().toString();
    String authCode;
    boolean authComplete = false;

    Intent resultIntent = new Intent();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_networks);

        Button toFacebookLogin = findViewById(R.id.toFacebookLogin);
        toFacebookLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(ManageNetworks.this, FacebookLogin.class);
                startActivity(i);
            }
        });

        Button toTwitterLogin = findViewById(R.id.toTwitterLogin);
        toTwitterLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(ManageNetworks.this, TwitterLogin.class);
                startActivity(i);
            }
        });

        Button toRedditLogin = findViewById(R.id.toRedditLogin);
        toRedditLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(ManageNetworks.this, RedditLogin.class);
                startActivity(i);
            }
        });

        Log.d("AccessToken", Variables.getInstance().getRedditAccessToken());

    }
}