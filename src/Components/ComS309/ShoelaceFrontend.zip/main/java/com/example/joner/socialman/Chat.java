package com.example.joner.socialman;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import org.java_websocket.exceptions.WebsocketNotConnectedException;

/**
 * This Activity show the chat UI. The UI contains a recycler view, a text box and a send button.
 * When the message is sent it will call the send method of the websocket client in the Variables class.
 */
public class Chat extends AppCompatActivity {

    private RecyclerView.LayoutManager layoutManager;
    private TextView chatMessage;
    private Button sendMessage;
    private Toolbar toolbar;
    private String friend;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.navHome:
                    Intent i = new Intent(Chat.this, MainActivity.class);
                    startActivity(i);
                    return true;
                case R.id.createPost:
                    i = new Intent(Chat.this, CreatePost.class);
                    startActivity(i);
                    return true;
                case R.id.account:
                    i = new Intent(Chat.this, AccountSettings.class);
                    startActivity(i);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        friend = getIntent().getStringExtra("friend");
        toolbar = findViewById(R.id.ChatToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(friend);

        chatMessage = findViewById(R.id.ChatMessage);
        sendMessage = findViewById(R.id.ChatSend);
        initRecyclerView();

        sendMessage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try{
                    Log.d("friendName", friend);
                    Log.d("chatMessage", chatMessage.getText().toString());
                    Variables.getInstance().getWebSocketClient().send("@" + friend + " " + chatMessage.getText().toString());
                    Variables.currentChatName = friend;

                } catch(WebsocketNotConnectedException e){
                    Log.d("Websocket_error", e.toString());
                }

            }
        });


    }

    /**
     * Initializes the recyclerView that is used for the scrolling list of chats.
     * It uses variables in the Variables class so that the chats can stay active after changing the activity
     */
    private void initRecyclerView() {
        Variables.ChatRecycler = findViewById(R.id.chatRecycler);
        Variables.getInstance().setChatAdapter(new ChatAdapter(this, Variables.getInstance().getChats().get(Variables.currentChatNumber)));
        Variables.ChatRecycler.setHasFixedSize(true);
        Variables.ChatRecycler.setAdapter(Variables.getInstance().getChatAdapter());
        layoutManager = new LinearLayoutManager(this);
        Variables.ChatRecycler.setLayoutManager(layoutManager);
        Variables.ChatRecycler.smoothScrollToPosition(Variables.getInstance().getChats().get(Variables.currentChatNumber).size());
    }
}
