package com.example.joner.socialman;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Activity for creating account
 */
public class CreateAccount extends AppCompatActivity {

    Button create;
    TextView name;
    TextView email;
    TextView password1;
    TextView password2;
    TextView mTextView;
    String TAG = "CreateAccount";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);


        create = findViewById(R.id.account_create);
        name = findViewById(R.id.account_name);
        email = findViewById(R.id.account_email);
        password1 = findViewById(R.id.account_password1);
        password2 = findViewById(R.id.account_password2);
        mTextView = findViewById(R.id.tempTextView);

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().length() == 0) {
                    Toast message = Toast.makeText(getApplicationContext(), "Name cannot be blank", Toast.LENGTH_LONG);
                    message.show();
                    return;
                }
                if (email.getText().toString().length() == 0) {
                    Toast message = Toast.makeText(getApplicationContext(), "Email cannot be blank", Toast.LENGTH_LONG);
                    message.show();
                    return;
                }
                if (password1.getText().toString().length() == 0) {
                    Toast message = Toast.makeText(getApplicationContext(), "Password cannot be blank", Toast.LENGTH_LONG);
                    message.show();
                    return;
                }
                if (!password1.getText().toString().equals(password2.getText().toString())) {
                    Toast message = Toast.makeText(getApplicationContext(), "Passwords do not match", Toast.LENGTH_LONG);
                    message.show();
                    return;
                }

                // Instantiate the RequestQueue.
                RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                String url = "http://proj309-mg-01.misc.iastate.edu:8080/users/new";

                JSONObject payload = null;
                try {
                    payload = new JSONObject()
                            .put("name", name.getText())
                            .put("email", email.getText())
                            .put("password", password1.getText());
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                JsonObjectRequest postRequest = new JsonObjectRequest(url, payload,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {


                                //TODO Add logic to make sure user doesn't already exist in DB
                                User.setCurrentUser(User.fromJson(response));
                                Log.d(TAG, "User created: " + User.getCurrentUser().getName());
                                Log.d(TAG, "User ID: " + User.getCurrentUser().getId());
                                //TODO Do we want to automatically launch feed?
                                Intent i = new Intent(CreateAccount.this, MainActivity.class);
                                startActivity(i);

                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Log.d(TAG, "Error " + error.getMessage());
                                Toast t = Toast.makeText(getApplicationContext(), "Server Error, check log", Toast.LENGTH_SHORT);
                                t.show();
                            }
                        }
                );
                queue.add(postRequest);

            }

        });
    }
}
