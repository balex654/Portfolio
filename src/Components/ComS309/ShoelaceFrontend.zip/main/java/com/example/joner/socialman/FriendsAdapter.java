package com.example.joner.socialman;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Adapter for friends list
 */
public class FriendsAdapter extends RecyclerView.Adapter<FriendsAdapter.ViewHolder> {
    @NonNull
    private static final String TAG = "FriendsAdapter";
    private ArrayList<User> friends;
    private Context mContext;
    private boolean bindListener;

    /**
     * Construct a new adapter
     * @param c Context
     * @param friends
     */
    public FriendsAdapter(@NonNull Context c, ArrayList<User> friends, boolean bindListener) {
        this.mContext = c;
        this.friends = friends;
        this.bindListener = bindListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_friend, viewGroup, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }



    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {
        Log.d(TAG, "OnBindViewHolder: called");

        //Load and set image
        Glide.with(mContext)
                .asBitmap()
                .load(friends.get(i).getImageURL())
                .into(viewHolder.image);
        //Set name
        viewHolder.name.setText(friends.get(i).getName());
        if(bindListener) {
            viewHolder.parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(mContext, "Long click to add friend", Toast.LENGTH_LONG).show();
                }
            });

            viewHolder.parent.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    Log.d(TAG, "Long click");
                    Log.d(TAG, "Array size: " + friends.size());
                    Log.d(TAG, "Removing user " + i + " from recycler view.");
                    RequestQueue queue = Volley.newRequestQueue(mContext);

                    String url = new StringBuilder()
                            .append("http://proj309-mg-01.misc.iastate.edu:8080/users/")
                            .append(User.getCurrentUser().getId())
                            .append("/addbyid/")
                            .append(friends.get(i).getId())
                            .toString();

                    Log.d("Array Request", url);

                    JSONObject payload = new JSONObject();


                    JsonObjectRequest request = new JsonObjectRequest(url, payload,
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {
                                        Toast.makeText(mContext, "Friend added!", Toast.LENGTH_LONG).show();
                                        friends.remove(i);
                                        notifyDataSetChanged();
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Log.d(TAG, "Error " + error.getMessage());
                                    Toast t = Toast.makeText(mContext, "Server Error, check log", Toast.LENGTH_SHORT);
                                    t.show();
                                }
                            }
                    );
                    queue.add(request);
                    return true;
                }
            });

        } else {
            viewHolder.parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, FriendHistory.class);
                    intent.putExtra("id", friends.get(i).getId());
                    mContext.startActivity(intent);
                }
            });

        }
    }

    @Override
    public int getItemCount() {
        return friends.size();
    }

    /**
     * ViewHolder for Friends
     */
    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView name;
        RelativeLayout parent;



        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.friend_image);
            name = itemView.findViewById(R.id.friend_name);
            parent = itemView.findViewById(R.id.friend_rl);
        }
    }

}
