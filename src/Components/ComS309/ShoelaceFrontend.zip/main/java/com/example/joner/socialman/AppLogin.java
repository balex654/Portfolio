package com.example.joner.socialman;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.Set;

import static android.content.Context.MODE_PRIVATE;
import static com.facebook.FacebookSdk.getApplicationContext;

/**
 * Activity that gets the specified user information from the server and logs in to the app.
 * Uses Android Volley get request to get data from the server
 */
public class AppLogin extends AppCompatActivity {
    private TextView email;
    private TextView password;
    private Button login;
    private String TAG = "AppLogin";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_login);
        login = findViewById(R.id.appLogin);
        email = findViewById(R.id.appEmail);
        password = findViewById(R.id.appPassword);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (email.getText().toString().length() == 0){
                    Toast message = Toast.makeText(getApplicationContext(), "Username cannot be blank", Toast.LENGTH_LONG);
                    message.show();
                    return;
                }
                if (password.getText().toString().length() == 0){
                    Toast message = Toast.makeText(getApplicationContext(), "Password cannot be blank", Toast.LENGTH_LONG);
                    message.show();
                    return;
                }


                Intent i = new Intent(AppLogin.this, MainActivity.class);
                startActivity(i);


                // Instantiate the RequestQueue.
                RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                String url ="http://proj309-mg-01.misc.iastate.edu:8080/checkUser/";

                url = url + email.getText().toString() + "/" + password.getText().toString();


                //TODO finish JSON HTTP post request
                JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, null,
                        new Response.Listener<JSONObject>()
                        {
                            @Override
                            public void onResponse(JSONObject response) {
                                Log.d(TAG, "Response from server: " + response.toString());
                                User user = User.fromJson(response);
                                User.setCurrentUser(user);
                                Util.fetchPostsFromDB(getApplicationContext());

                                SharedPreferences.Editor editor = getSharedPreferences("login data", MODE_PRIVATE).edit();
                                editor.putString("user email", email.getText().toString());
                                editor.putString("user password", password.getText().toString());
                                editor.apply();

                                SharedPreferences.Editor editor2 = getSharedPreferences("manual logout", MODE_PRIVATE).edit();
                                editor2.putString("logout", "");
                                editor2.apply();

                                Intent i = new Intent(AppLogin.this, MainActivity.class);
                                startActivity(i);
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Log.d(TAG, "Volley error " + error.getMessage());
                                error.printStackTrace();
                            }
                        }
                );
                queue.add(postRequest);

            }
        });
    }
}
