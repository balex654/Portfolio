package com.example.joner.socialman;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

/**
 * Main feed
 */
public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private String TAG = "MainActivity";
    private ArrayList<Post> posts = new ArrayList<>();
    private String CHANNEL_ID = "1";

    /**
     * Sets BottomNavigationLister
     */
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.navHome:
                    return true;
                case R.id.createPost:

                    Intent i = new Intent(MainActivity.this, CreatePost.class);
                    startActivity(i);
                    return true;
                case R.id.account:
                    i = new Intent(MainActivity.this, AccountSettings.class);
                    startActivity(i);
                    return true;
            }
            return false;
        }
    };

    /**
     * Callback for menu items
     * @param item
     * @return boolean
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_chat:
                Intent i = new Intent(MainActivity.this, Conversations.class);
                startActivity(i);

            default:
                return super.onOptionsItemSelected(item);

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        //FOR TESTING
        User user = new User();
        user.setName("Ben");
        user.setPassword("123");
        user.setEmail("balex@aiastate.edu");
        user.setId(1);
        User.setCurrentUser(user);



        //Log.d(TAG, "onCreate called");
        //Log.d(TAG, "CURRENT USER: " + User.getCurrentUser().getName());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        setSupportActionBar((Toolbar) findViewById(R.id.my_toolbar));


        //Util.fetchPostsFromDB(getApplicationContext());

        Refresh r = new Refresh();
        if(Variables.getInstance().getLoggedInTwitter()){
            r.getTweets(Variables.getInstance().getTwitterSession(), false);
        }
        if(Variables.getInstance().getLoggedInFacebook()){
            r.graphRequest(Variables.getInstance().getFBAccessToken(), false);
        }
        if(Variables.getInstance().getLoggedInReddit()){
            r.RedditPosts(Variables.getInstance().getRedditAccessToken(), false);
        }

        shufflePosts();
        initRecyclerView();

        navigation.setSelectedItemId(R.id.navHome);
    }

    /**
     * Initializes RecyclerView
     */
    private void initRecyclerView() {
        Log.d(TAG, "initRecyclerView called");
        recyclerView = findViewById(R.id.recyclerview);
        Log.d(TAG, "" + Variables.getInstance().getAppPosts().size());
        Variables.getInstance().setAdapter(new MyAdapter(this, Variables.getInstance().getFeedPosts()));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(Variables.getInstance().getPostAdapter());
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
    }


    /**
     * Shuffles posts from multiple sources
     */
    private void shufflePosts() {
        Variables.getInstance().getFeedPosts().clear();

        int RedditPosts = Variables.getInstance().getRedditPosts().size();
        int FBposts = Variables.getInstance().getPostsFB().size();
        int TwitterPosts = Variables.getInstance().getPostsTwitter().size();
        int feedLength = Math.max(FBposts, Math.max(TwitterPosts, RedditPosts));

        for (int i = 0; i < feedLength; i++) {
            if (i < RedditPosts){
                Variables.getInstance().getFeedPosts().add(Variables.getInstance().getRedditPosts().get(i));
            }
            if (i < FBposts) {
                Variables.getInstance().getFeedPosts().add(Variables.getInstance().getPostsFB().get(i));
            }
            if (i < TwitterPosts) {
                Variables.getInstance().getFeedPosts().add(Variables.getInstance().getPostsTwitter().get(i));
            }
        }
    }

    /**
     * Inflates menu
     * @param menu
     * @return boolean
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar, menu);
        return super.onCreateOptionsMenu(menu);
    }
}