package com.example.joner.socialman;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

/**
 * An activity to display details for a post
 */
public class PostDetails extends AppCompatActivity {
    private Bitmap myBitmap;

    /**
     * When a user taps on an item in the recyclerView associated with MyAdapter, They are brought to
     * this activity that shows a larger view of the image and more text.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_details);

        //I updated this so the selected post is passed by Intent.
        Post selectedPost = (Post) getIntent().getSerializableExtra("post");

        TextView name = findViewById(R.id.postDetailName);
        name.setText(selectedPost.getName());

        TextView source = findViewById(R.id.postDetailsSource);
        source.setText(selectedPost.getSource());

        TextView caption = findViewById(R.id.postDetailsCaption);
        caption.setText(selectedPost.getDescription());

        ImageView image = findViewById(R.id.postDetailsImage);
        Glide.with(image)
                .asBitmap()
                .load(selectedPost.getImageURL())
                .into(image);

    }
}
