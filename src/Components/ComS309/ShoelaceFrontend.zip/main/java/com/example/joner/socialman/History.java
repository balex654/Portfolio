package com.example.joner.socialman;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Shows the history of posts made by the user in the app
 */
public class History extends AppCompatActivity {

    private ArrayList<Post> posts = new ArrayList<>();
    private RecyclerView historyView;
    LinearLayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        posts = Variables.getInstance().getAppPosts();
        initRecyclerView();

    }

    /**
     * Initializes the recyclerView used for the activity, the recycler uses MyAdatper just
     * like the mainActivity
     */
    private void initRecyclerView() {
        historyView = findViewById(R.id.historyRecycler);
        Variables.getInstance().setAdapter(new MyAdapter(this, posts));
        historyView.setHasFixedSize(true);
        historyView.setAdapter(Variables.getInstance().getPostAdapter());
        layoutManager = new LinearLayoutManager(this);
        historyView.setLayoutManager(layoutManager);
    }
}
