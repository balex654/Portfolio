package com.example.joner.socialman;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;


/**
 * Show a scrollable list of all the user's friends that the user can chat with.
 */
public class Conversations extends AppCompatActivity {

    private String TAG = "Friends";
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.navHome:
                    Intent i = new Intent(Conversations.this, MainActivity.class);
                    startActivity(i);
                    return true;
                case R.id.createPost:
                    i = new Intent(Conversations.this, CreatePost.class);
                    startActivity(i);
                    return true;
                case R.id.account:
                    i = new Intent(Conversations.this, AccountSettings.class);
                    startActivity(i);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversations);
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        initRecyclerView();

    }

    /**
     * Initializes the recyclerView used to show the scrollable list. The recyclerView uses TempAdapter to show the list
     */
    private void initRecyclerView() {
        Log.d(TAG, "initRecyclerView called");
        recyclerView = findViewById(R.id.converse_recyclerview);
        adapter = new TempAdapter(this, Variables.getInstance().getFriends());
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
    }

}
