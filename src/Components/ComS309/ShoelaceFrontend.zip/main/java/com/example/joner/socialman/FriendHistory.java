package com.example.joner.socialman;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

/**
 * Shows the history of posts made by the user in the app
 */
public class FriendHistory extends AppCompatActivity {

    private ArrayList<Post> posts = new ArrayList<>();
    private RecyclerView historyView;
    LinearLayoutManager layoutManager;
    private MyAdapter adapter;
    private String TAG = "FriendHistory";
    private TextView message;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_chat:
                Intent i = new Intent(FriendHistory.this, Conversations.class);
                startActivity(i);

            default:
                return super.onOptionsItemSelected(item);

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_history);
        setSupportActionBar((Toolbar) findViewById(R.id.my_toolbar));
        message = findViewById(R.id.noPostsText);
        setTitle("Post History");
        initRecyclerView();
        RequestQueue queue = Volley.newRequestQueue(this);

        String url = new StringBuilder()
                .append("http://proj309-mg-01.misc.iastate.edu:8080/users/")
                .append(getIntent().getIntExtra("id", 1))
                .append("/posts")
                .toString();

        Log.d("Array Request", url);
        JsonArrayRequest request = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        if(response.length() == 0)
                            message.setVisibility(View.VISIBLE);
                        for (int i = response.length() - 1; i >= 0; i--) {
                            try {

                                Log.d("postFromJSON", String.valueOf(i));
                                posts.add(Post.fromDB(response.getJSONObject(i)));
                                adapter.notifyDataSetChanged();

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        Log.d("DB posts", response.toString());

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Error " + error.getMessage());
                        error.printStackTrace();
                    }
                }

        );


        queue.add(request);

    }


    private void initRecyclerView() {
        historyView = findViewById(R.id.friendhistoryrecyclerview);
        adapter = new MyAdapter(this, posts);
        Variables.getInstance().setAdapter(adapter);
        historyView.setHasFixedSize(true);
        historyView.setAdapter(Variables.getInstance().getPostAdapter());
        layoutManager = new LinearLayoutManager(this);
        historyView.setLayoutManager(layoutManager);
    }
}
