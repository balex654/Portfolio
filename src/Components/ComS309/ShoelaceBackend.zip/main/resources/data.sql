INSERT INTO cs309.user VALUES (1,'tim@iastate.edu','tim','pw');

INSERT INTO cs309.post VALUES (1,'new FB post','img','01-02-2018 10 am');

INSERT INTO cs309.user_posts VALUES (1,1);
