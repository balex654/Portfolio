package com.example.demo.UserName;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.imageio.ImageIO;

import org.jboss.logging.FormatWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * the user controller
 * @author durgadarba arikr
 *
 */
@RestController
public class UserController {

	@Autowired
	UserRepository UserRepository;

	/**
	 * gets the user's post
	 * @param userId the user's id
	 * @return posts the user's posts
	 */
	@RequestMapping(method = RequestMethod.GET, path = "/users/{userId}/posts")
    public List<Post> getPosts(@PathVariable("userId") int userId ) {  //need to add user attribute posts
        return UserRepository.findById(userId).get().getPosts();
    }
	
	/**
	 * gets user's friends
	 * @param userId the user's id
	 * @return a list of friends
	 */
	@RequestMapping(method = RequestMethod.GET, path = "/users/{userId}/friends")
    public List<User> getFriends(@PathVariable("userId") int userId ) {  //need to add user attribute posts
        return UserRepository.findById(userId).get().getFriends();
    }
	
	/**
	 * creates a new post from user
	 * @param post a new post to be created
	 * @param userId the user's id
	 * @return the post that was created
	 */
	@RequestMapping(method = RequestMethod.POST, path = "/users/{userId}/newpost") //need to add this to the posts attribute
    public Post makePost(@RequestBody Post post, @PathVariable("userId") int userId) {
		Optional<User> user = UserRepository.findById(userId);
		if(user.isPresent()) {
			List<Post> posts = user.get().getPosts();
			posts.add(post);
			UserRepository.save(user.get());
			return post;
		}
		else {
			return post;
		}
    }
	
	/**
	 * adds friends by id
	 * @param userId the user's id
	 * @param friend the friend's id
	 * @return the User object of friend or null if the user isn't present
	 */
	@RequestMapping(method = RequestMethod.POST, path = "/users/{userId}/addbyid/{friend}") //need to add this to the posts attribute
    public User addFriend(@PathVariable("userId") int userId, @PathVariable("friend") int friend) {
		Optional<User> user = UserRepository.findById(userId);
		Optional<User> toAdd = UserRepository.findById(friend);
		if(user.isPresent() & toAdd.isPresent()) {
			user.get().getFriends().add(toAdd.get());
			toAdd.get().getFriends().add(user.get());
			UserRepository.save(user.get());
			UserRepository.save(toAdd.get());
			return toAdd.get();
		}
		else {
			return null;
		}
    }
	
	/**
	 * creates a new user
	 * @param newUser the new user
	 * @return the User
	 */
	@PostMapping("/users/new")
	User newUser(@RequestBody User newUser) {
		return UserRepository.save(newUser);
	}

	/**
	 * gets all users
	 * @return a list of all users
	 */
	@RequestMapping(method = RequestMethod.GET, path = "/users")
	public List<User> getAllUsers() {
		List<User> results = (List<User>) UserRepository.findAll();

		return results;
	}

	/**
	 * finds a specific user by id
	 * @param id the user's id
	 * @return returns the User object
	 */
	@RequestMapping(method = RequestMethod.GET, path = "/users/{userId}")
	public Optional<User> findUserById(@PathVariable("userId") Integer id) {

		Optional<User> results = UserRepository.findById(id);
		return results;
	}
	
	/**
	 * gets the user's email and password
	 * @param email the user's email
	 * @param password the user's password
	 * @return the user's password
	 */
	//look into getting the email and password by request body?
	@RequestMapping(method = RequestMethod.POST, path = "/checkUser/{email}/{password}")
	public Optional<User> checkUser(@PathVariable("email") String email, @PathVariable("password") String password) {  //@RequestBody String[] credentials
		Optional<User> results = UserRepository.findUserByEmailAndPassword(email, password);
		return results;
		
	}
	
	@ResponseBody
	
	@RequestMapping(method = RequestMethod.POST, path = "/{extension}")
	public String uploadImg(@RequestBody byte[] bytes, @PathVariable("extension") String extension /*@RequestPart MultipartFile img*/) throws IOException{
		UUID uuid = UUID.randomUUID(); //randomly generate name
	    String imgName = uuid.toString() + "." + extension; 
	    InputStream in = new ByteArrayInputStream(bytes);
	    
		BufferedImage bImageFromConvert = ImageIO.read(in);
		ImageIO.write(bImageFromConvert, extension, new File("/var/www/html/" + imgName));

		imgName = "http://proj309-mg-01.misc.iastate.edu/" + imgName;
		
	    return imgName;
	}
	/*
	@ResponseBody
	@RequestMapping(method = RequestMethod.POST, path = "/")
	public String uploadImg(@RequestPart MultipartFile img) throws IOException{
		UUID uuid = UUID.randomUUID(); //randomly generate name
	    String imgName = uuid.toString();
	    BufferedImage img = ImageIO.read(new ByteArrayInputStream(bytes));
	    File upl = new File("/var/www/html/" + imgName);
	    upl.createNewFile();
	    FileOutputStream fout = new FileOutputStream(upl);
	    fout.write(img.getBytes());
	    fout.close();
	    return imgName;
	}
	*/
	/*
	@RequestMapping(method = RequestMethod.GET, path = "/{imgUrl}")
	public File getImg(@PathVariable("imgUrl") String imgUrl) throws IOException {
		File img = new ClassPathResource(imgUrl).getFile();
			return img;
	    }
	*/
	
}
