package com.example.demo.UserName;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Defines what a post is. 
 * @author durgadarba arikr
 *
 */
@Entity
public class Post {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String description;
	private String timeposted;
	private String imageURL;
	
	/**
	 * constructor that defines description, timeposted, and imageurl
	 */
	Post()
	{
		description = "";
		timeposted = "";
		imageURL = "";
	}
	
	/**
	 * getter method for the Description of post
	 * @return String gets the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * sets the description of post
	 * @param description takes a string description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * gets the the time the post is posted
	 * @return String the time posted
	 */
	public String getTimeposted() {
		return timeposted;
	}
	
	/**
	 * sets the time posted
	 * @param timeposted String of the time posted
	 */
	public void setTimeposted(String timeposted) {
		this.timeposted = timeposted;
	}

	/**
	 * gets the image url
	 * @return String of image url
	 */
	public String getImageURL() {
		return imageURL;
	}

	/**
	 * sets the image url
	 * @param imageURL String of image url
	 */
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}


	/**
	 * gets the id
	 * @return int of the post id
	 */
	public int getId() {
		return id;
	}

	/**
	 * sets the post's id
	 * @param id int of the id
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	
}
