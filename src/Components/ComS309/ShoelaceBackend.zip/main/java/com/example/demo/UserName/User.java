package com.example.demo.UserName;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.ManyToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Defines what a User is
 * @author durgadarba arikr
 *
 */
@Entity
public class User {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String email;
    private String password;
    
    @JsonIgnore
    @OneToMany(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Post> posts;
    
    @JsonIgnore
    @ManyToMany(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
    private List<User> friends;
    
   
    /**
     * Constructs the User 
     */
    public User() {}

    /**
     * Constructs the User
     * @param name String sets the user's name
     * @param id sets the user's id
     */
    public User(String name, int id) {
        this.name = name;
        this.id = id;
    }

    /**
     * get the user's id
     * @return Integer user's id
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the id of the user
     * @param id Integer the user's id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * returns the user's name
     * @return String of the user's name
     */
    public String getName() {
        return name;
    }

    /**
     * set the name of the user
     * @param name String the new name of the user
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * gets the user's email
     * @return String the user's email
     */
    public String getEmail()
    {
    	return email;
    }
    
    /**
     * sets the user's email
     * @param email String the user's  email
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * gets the users password
     * @return String the user's password
     */
    public String getPassword()
    {
    	return password;
    }
    
    /**
     * set's the user's new password
     * @param password String the user's password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    
    /**
     * creates a String version of User
     */
    @Override
    public String toString() {
        return "UserName{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

    /**
     * gets the posts the user has made
     * @return List<Post> a post list array
     */
	public List<Post> getPosts() {
		return posts;
	}

	/**
	 * sets a post
	 * @param posts which post to select
	 */
	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}

	/**
	 * get's the users 
	 * @return List<User> user's list of friends
	 */
	public List<User> getFriends(){
		return friends;
	}
	
	/**
	 * sets a friend in user.
	 * @param List<User> a friend to set
	 */
	public void setFriends(List<User> friends) {
		this.friends = friends;
	}
	
}