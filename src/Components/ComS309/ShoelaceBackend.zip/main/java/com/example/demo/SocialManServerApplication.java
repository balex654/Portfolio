package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialManServerApplication{

	public static void main(String[] args) {
		SpringApplication.run(SocialManServerApplication.class, args);
		
//		UserController u = new UserController();
//		List<User> l = new ArrayList<User>();
	}
}
