package assignment1;

import java.util.Scanner;

/**
 * This game UI will display on the console window. I made this to initially test the TicTacToe class
 * @author Ben Alexander
 *
 */
public class Main {
	public static void main(String[] args){
		TicTacToe game = new TicTacToe();
		boolean spotTaken = false;
		char player = 'X';
		boolean gameWon = false;
		while(!gameWon){
			if(!spotTaken){
				if(player == 'X'){
					player = 'O';
					System.out.println("Player 'O', enter move: ");
				}
				else if(player == 'O'){
					player = 'X';
					System.out.println("Player 'X', enter move: ");
				}
			}
			else{
				if(player == 'X'){
					System.out.println("Player 'X', enter move: ");
				}
				else if(player == 'O'){
					System.out.println("Player 'O', enter move: ");
				}
				spotTaken = false;
			}
			Scanner in = new Scanner(System.in);
			String move = in.nextLine();
			
			if(!game.makeMove(move, player)){
				System.out.println("Spot has been taken, try again");
				spotTaken = true;
			}
			else if(game.checkGame() == 'T'){
				game.showGame();
				System.out.println("The game is a tie");
				System.out.println("Restart? (yes or no)");
				Scanner in2 = new Scanner(System.in);
				String restart = in2.nextLine();
				if(restart.equals("yes")){
					game.reset();
				}
				else{
					gameWon = true;
				}
			}
			else if(game.checkGame() == 'O'){
				game.showGame();
				System.out.println("O has won the game!");
				System.out.println("Restart? (yes or no)");
				Scanner in2 = new Scanner(System.in);
				String restart = in2.nextLine();
				if(restart.equals("yes")){
					game.reset();
				}
				else{
					gameWon = true;
				}
			}
			else if(game.checkGame() == 'X'){
				game.showGame();
				System.out.println("X has won the game!");
				System.out.println("Restart? (yes or no)");
				Scanner in2 = new Scanner(System.in);
				String restart = in2.nextLine();
				if(restart.equals("yes")){
					game.reset();
				}
				else{
					gameWon = true;
				}
			}
			else{
				game.showGame();
			}

		}
	}
}