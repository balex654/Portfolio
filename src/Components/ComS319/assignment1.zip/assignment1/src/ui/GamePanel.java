package ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JPanel;
import assignment1.TicTacToe;

/**
 * Main panel for the user interface in a game.
 * 
 * @author Ben Alexander
 */
public class GamePanel extends JPanel {
	/**
	 * Suppress compiler warning.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Score panel associated with the game.
	 */
	private ScorePanel scorePanel;

	
	private TicTacToe match;
	private int x;
	private int y;
	private char player = 'O';
	private boolean done = false;
	
	/**
	 * These keep track of what is occupying the cells on the grid
	 */
	private boolean topLeftO = false;
	private boolean topLeftX = false;
	private boolean topMiddleO = false;
	private boolean topMiddleX= false;
	private boolean topRightO = false;
	private boolean topRightX = false;
	private boolean middleLeftO = false;
	private boolean middleLeftX = false;
	private boolean middleO = false;
	private boolean middleX = false;
	private boolean middleRightO = false;
	private boolean middleRightX = false;
	private boolean bottomLeftO = false;
	private boolean bottomLeftX = false;
	private boolean bottomMiddleO = false;
	private boolean bottomMiddleX = false;
	private boolean bottomRightO = false;
	private boolean bottomRightX = false;
	
	/**
	 * Constructs a GamePanel with the given game associated ScorePanel.
	 * 
	 * @param scorePanel - panel for displaying scores associated with the game
	 */
	public GamePanel(ScorePanel scorePanel, TicTacToe match) {
		this.scorePanel = scorePanel;
		this.match = match;
		addMouseListener(new MyMouseListener());
	}

	/**
	 * Start over with a new game.
	 * 
	 * @param game
	 */
	public void reset() {
		player = 'O';
		done = false;
		x = 0;
		y = 0;
		
		topLeftO = false;
		topLeftX = false;
		topMiddleO = false;
		topMiddleX= false;
		topRightO = false;
		topRightX = false;
		middleLeftO = false;
		middleLeftX = false;
		middleO = false;
		middleX = false;
		middleRightO = false;
		middleRightX = false;
		bottomLeftO = false;
		bottomLeftX = false;
		bottomMiddleO = false;
		bottomMiddleX = false;
		bottomRightO = false;
		bottomRightX = false;
		scorePanel.reset();
		
		match.reset();
		
		repaint();
	}
	
	/**
	 * Used for making an X or an O in the grid position where the mouse was clicked
	 */
	@Override
	public void paintComponent(Graphics g) {
		// clear background
		g.setColor(GameMain.BACKGROUND_COLOR);
		g.fillRect(0, 0, getWidth(), getHeight());
	    
		g.setColor(GameMain.GRID_COLOR);
	    g.fillRect(110, 40, 5, 220);
	    
	    g.setColor(GameMain.GRID_COLOR);
	    g.fillRect(190, 40, 5, 220);
	    
	    g.setColor(GameMain.GRID_COLOR);
	    g.fillRect(40, 110, 220, 5);
	    
	    g.setColor(GameMain.GRID_COLOR);
	    g.fillRect(40, 190, 220, 5);
		
	    if(!done){
	    	if((x >= 40 && x <= 110 && y >= 40 && y <=110) && !topLeftO && !topLeftX){
	    		x = 0;
	    		y = 0;
	    		if(player == 'X'){
					player = 'O';
				}
				else if(player == 'O'){
					player = 'X';
				}
				match.makeMove("top left", player);
				char r = match.checkGame();
				System.out.println(r);
				
				if(!topLeftO && !topLeftX){
					if(player == 'X'){
						makeX(g, 50, 50);
						topLeftX = true;
					}
					if(player == 'O'){
						makeO(g, 50, 50);
						topLeftO = true;
					}
				}
			}
			if(topLeftO){
				makeO(g, 50, 50);
			}
			if(topLeftX){
				makeX(g, 50, 50);
			}
			
			if((x >= 115 && x <= 190 && y >= 40 && y <=110) && !topMiddleO && !topMiddleX){
				x = 0;
				y = 0;
				if(player == 'X'){
					player = 'O';
				}
				else if(player == 'O'){
					player = 'X';
				}
				match.makeMove("top middle", player);
				char r = match.checkGame();
				System.out.println(r);
				if(!topMiddleO && !topMiddleX){
					if(player == 'X'){
						makeX(g, 130, 50);
						topMiddleX = true;
					}
					if(player == 'O'){
						makeO(g, 130, 50);
						topMiddleO = true;
					}
				}
			}
			if(topMiddleO){
				makeO(g, 130, 50);
			}
			if(topMiddleX){
				makeX(g, 130, 50);
			}
			
			if((x >= 200 && x <= 270 && y >= 40 && y <=110) && !topRightO && !topRightX){
				x = 0;
				y = 0;
				if(player == 'X'){
					player = 'O';
				}
				else if(player == 'O'){
					player = 'X';
				}
				match.makeMove("top right", player);
				char r = match.checkGame();
				System.out.println(r);
				if(!topRightO && !topRightX){
					if(player == 'X'){
						makeX(g, 210, 50);
						topRightX = true;
					}
					if(player == 'O'){
						makeO(g, 210, 50);
						topRightO = true;
					}
				}
			}
			if(topRightO){
				makeO(g, 210, 50);
			}
			if(topRightX){
				makeX(g, 210, 50);
			}
			
			if((x >= 40 && x <= 110 && y >= 118 && y <=193) && !middleLeftO && !middleLeftX){
				x = 0;
				y = 0;
				if(player == 'X'){
					player = 'O';
				}
				else if(player == 'O'){
					player = 'X';
				}
				match.makeMove("middle left", player);
				char r = match.checkGame();
				System.out.println(r);
				if(!middleLeftO && !middleLeftX){
					if(player == 'X'){
						makeX(g, 50, 130);
						middleLeftX = true;
					}
					if(player == 'O'){
						makeO(g, 50, 130);
						middleLeftO = true;
					}
				}
			}
			if(middleLeftO){
				makeO(g, 50, 130);
			}
			if(middleLeftX){
				makeX(g, 50, 130);
			}
			
			if((x >= 115 && x <= 190 && y >= 118 && y <=193) && !middleO && !middleX){
				x = 0;
				y = 0;
				if(player == 'X'){
					player = 'O';
				}
				else if(player == 'O'){
					player = 'X';
				}
				match.makeMove("middle", player);
				char r = match.checkGame();
				System.out.println(r);
				if(!middleO && !middleX){
					if(player == 'X'){
						makeX(g, 130, 130);
						middleX = true;
					}
					if(player == 'O'){
						makeO(g, 130, 130);
						middleO = true;
					}
				}
			}
			if(middleO){
				makeO(g, 130, 130);
			}
			if(middleX){
				makeX(g, 130, 130);
			}
			
			if((x >= 200 && x <= 270 && y >= 118 && y <=193) && !middleRightO && !middleRightX){
				x = 0;
				y = 0;
				if(player == 'X'){
					player = 'O';
				}
				else if(player == 'O'){
					player = 'X';
				}
				match.makeMove("middle right", player);
				char r = match.checkGame();
				System.out.println(r);
				if(!middleRightO && !middleRightX){
					if(player == 'X'){
						makeX(g, 210, 130);
						middleRightX = true;
					}
					if(player == 'O'){
						makeO(g, 210, 130);
						middleRightO = true;
					}
				}
			}
			if(middleRightO){
				makeO(g, 210, 130);
			}
			if(middleRightX){
				makeX(g, 210, 130);
			}
			
			if((x >= 40 && x <= 110 && y >= 200 && y <= 260) && !bottomLeftO && !bottomLeftX){
				x = 0;
				y = 0;
				if(player == 'X'){
					player = 'O';
				}
				else if(player == 'O'){
					player = 'X';
				}
				match.makeMove("bottom left", player);
				char r = match.checkGame();
				System.out.println(r);
				if(!bottomLeftO && !bottomLeftX){
					if(player == 'X'){
						makeX(g, 50, 210);
						bottomLeftX = true;
					}
					if(player == 'O'){
						makeO(g, 50, 210);
						bottomLeftO = true;
					}
				}
			}
			if(bottomLeftO){
				makeO(g, 50, 210);
			}
			if(bottomLeftX){
				makeX(g, 50, 210);
			}
			
			if((x >= 115 && x <= 190 && y >= 200 && y <=260) && !bottomMiddleO && !bottomMiddleX){
				x = 0;
				y = 0;
				if(player == 'X'){
					player = 'O';
				}
				else if(player == 'O'){
					player = 'X';
				}
				match.makeMove("bottom middle", player);
				char r = match.checkGame();
				System.out.println(r);
				if(!bottomMiddleO && !bottomMiddleX){
					if(player == 'X'){
						makeX(g, 130, 210);
						bottomMiddleX = true;
					}
					if(player == 'O'){
						makeO(g, 130, 210);
						bottomMiddleO = true;
					}
				}
			}
			if(bottomMiddleO){
				makeO(g, 130, 210);
			}
			if(bottomMiddleX){
				makeX(g, 130, 210);
			}
			
			if((x >= 200 && x <= 270 && y >= 200 && y <=260) && !bottomRightO && !bottomRightX){
				x = 0;
				y = 0;
				if(player == 'X'){
					player = 'O';
				}
				else if(player == 'O'){
					player = 'X';
				}
				match.makeMove("bottom right", player);
				char r = match.checkGame();
				System.out.println(r);
				if(!bottomRightO && !bottomRightX){
					if(player == 'X'){
						makeX(g, 210, 210);
						bottomRightX = true;
					}
					if(player == 'O'){
						makeO(g, 210, 210);
						bottomRightO = true;
					}
				}
			}
			if(bottomRightO){
				makeO(g, 210, 210);
			}
			if(bottomRightX){
				makeX(g, 210, 210);
			}
	    }
	    
	    
		if (match.checkGame() == 'O' || match.checkGame() == 'X') {
			scorePanel.gameOver(player);
			done = true;
		}
		else if(match.checkGame() == 'T'){
			scorePanel.tie();
			done = true;
		}
		else if(match.checkGame() == 'C'){
			if(player == 'O'){
				scorePanel.currentPlayer('X');
			}
			if(player == 'X'){
				scorePanel.currentPlayer('O');
			}
		}
	}
	
	/**
	 * Makes an X at the specified x and y coordinates
	 * @param g
	 * @param xCord
	 * @param yCord
	 */
	private void makeX(Graphics g, int xCord, int yCord){
		g.setColor(Color.BLUE);
		((Graphics2D) g).setStroke(new BasicStroke(GameMain.LINE_SIZE));
		
		g.drawLine(xCord, yCord, xCord + 40, yCord + 40);
		g.drawLine(xCord, yCord + 40, xCord + 40, yCord);
		
	}
	/**
	 * Makes an O at the specified x and y coordinates
	 * @param g
	 * @param xCord
	 * @param yCord
	 */
	private void makeO(Graphics g, int xCord, int yCord){
		g.setColor(Color.RED);
		((Graphics2D) g).setStroke(new BasicStroke(GameMain.LINE_SIZE));
		g.drawOval(xCord, yCord, 40, 40);
	}

	/**
	 * Callback for mouse events.
	 */
	private class MyMouseListener implements MouseListener {
		
		/**
		 * If the mouse is clicked, this will record where it was clicked in the panel
		 */
		@Override
		public void mouseClicked(MouseEvent event) {
			x = event.getX();
			y = event.getY();
			System.out.println(x + " " + y);
			if(!done){
				repaint();
			}
		}

		@Override
		public void mousePressed(MouseEvent event) {

		}

		@Override
		public void mouseReleased(MouseEvent event) {

		}

		@Override
		public void mouseEntered(MouseEvent e) {
		}

		@Override
		public void mouseExited(MouseEvent e) {
		}
	}
}