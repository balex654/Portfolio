package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

/**
 * Panel for displaying the score in a simple video game.
 * 
 * @author Ben Alexander
 */
public class ScorePanel extends JPanel {
	/**
	 * Suppress compiler warning.
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * current player
	 */
	private char player;

	/**
	 * Flag indicating that the game is over.
	 */
	private boolean done = false;
	
	/**
	 * Flag indicating that the game is a tie.
	 */
	private boolean tie = false;

	/**
	 * Resets the score to zero and clears the 'done' and 'tie' flag.
	 */
	public void reset() {
		done = false;
		tie = false;
		repaint();
	}
	
	/**
	 * Sets the 'done' flag.
	 */
	public void gameOver(char player) {
		done = true;
		this.player = player;
		repaint();
	}
	
	/**
	 * Sets the 'tie' flag.
	 */
	public void tie(){
		tie = true;
		repaint();
	}
	
	/**
	 * determines what the current player is
	 * @param player
	 */
	public void currentPlayer(char player){
		this.player = player;
		repaint();
	}
	
	/**
	 * Used to paint the text
	 */
	@Override
	public void paintComponent(Graphics g) {
		((Graphics2D) g).setBackground(Color.WHITE);
		g.clearRect(0, 0, getWidth(), getHeight());
		Font font = new Font(Font.SANS_SERIF, Font.PLAIN, GameMain.SCORE_FONT);
		g.setFont(font);

		String text;
		if (done) {
			text = player + " has won the game!";
		} 
		else if(tie){
			text = "Game is a tie";
		}
		else {
			text = "Player " + player + " enter move";
		}

		g.drawString(text, 10, 50);
	}
}
