package ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * Panel used for displaying and operating the restart button
 * 
 * @author Ben Alexander
 */
public class ChooseButtonPanel extends JPanel {
	/**
	 * Suppress compiler warning.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * restart button
	 */
	private JButton button;

	/**
	 * Panel for the associated game. This reference is needed here to reset the game
	 */
	private GamePanel gamePanel;


	/**
	 * Constructs the restart button panel.
	 * 
	 * @param gamePanel
	 * @param scorePanel
	 */
	public ChooseButtonPanel(GamePanel gamePanel, ScorePanel scorePanel) {
		this.gamePanel = gamePanel;
		button = new JButton("Restart");
		this.add(button);
		button.addActionListener(new ChooseButtonHandler());
	}
	
	/**
	 * Controls what happens when the button is pressed
	 * @author benalexander
	 *
	 */
	private class ChooseButtonHandler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent event) {
			gamePanel.reset();
		}
	}
}
