package edu.iastate.cs228.hw4;

public class Test {
	public static void main(String[] args){
		EntryTree<Character, String> tree = new EntryTree<Character, String>();
		
		String keys = "edit";
		Character[] keyarr = new Character[keys.length()];
		for(int i = 0; i < keys.length(); i++){
			keyarr[i] = keys.charAt(i);
		}
		tree.add(keyarr, "change");
		
		String keys2 = "edited";
		Character[] keyarr2 = new Character[keys2.length()];
		for(int i = 0; i < keys2.length(); i++){
			keyarr2[i] = keys2.charAt(i);
		}
		tree.add(keyarr2, "revised");
		
		String keys3 = "edict";
		Character[] keyarr3 = new Character[keys3.length()];
		for(int i = 0; i < keys3.length(); i++){
			keyarr3[i] = keys3.charAt(i);
		}
		tree.add(keyarr3, "order");
		
		String keys4 = "editor";
		Character[] keyarr4 = new Character[keys4.length()];
		for(int i = 0; i < keys4.length(); i++){
			keyarr4[i] = keys4.charAt(i);
		}
		tree.add(keyarr4, "writer");
		
		String keys5 = "edition";
		Character[] keyarr5 = new Character[keys5.length()];
		for(int i = 0; i < keys5.length(); i++){
			keyarr5[i] = keys5.charAt(i);
		}
		tree.add(keyarr5, "version");
		
		String keys6 = "editorial";
		Character[] keyarr6 = new Character[keys6.length()];
		for(int i = 0; i < keys6.length(); i++){
			keyarr6[i] = keys6.charAt(i);
		}
		tree.add(keyarr6, "opinion");
		
		String keys7 = "edge";
		Character[] keyarr7 = new Character[keys7.length()];
		for(int i = 0; i < keys7.length(); i++){
			keyarr7[i] = keys7.charAt(i);
		}
		tree.add(keyarr7, "sharpness");
		
		String keys8 = "edge";
		Character[] keyarr8 = new Character[keys8.length()];
		for(int i = 0; i < keys8.length(); i++){
			keyarr8[i] = keys8.charAt(i);
		}
		System.out.println(tree.search(keyarr8));
		
		String keys9 = "editorialized";
		Character[] keyarr9 = new Character[keys9.length()];
		for(int i = 0; i < keys9.length(); i++){
			keyarr9[i] = keys9.charAt(i);
		}
		
		System.out.println(tree.prefix(keyarr9));
	}
}
