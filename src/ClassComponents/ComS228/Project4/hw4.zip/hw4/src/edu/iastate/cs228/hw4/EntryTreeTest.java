package edu.iastate.cs228.hw4;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import edu.iastate.cs228.hw4.EntryTree;
import edu.iastate.cs228.hw4.EntryTree.Node;

public class EntryTreeTest {
	private EntryTree<Character, String> tree;
	
	/**
	 * Sets up the EntryTree 
	 */
	@Before
	public void construct(){
		tree = new EntryTree<Character, String>();
	}
	
	/**
	 * Test to determine if add throws a NullPointerException when given a keyarr
	 * with a null item in it
	 */
	@Test(expected = NullPointerException.class)
	public void addTest1(){
		Character[] keys = {'a', 'b', null, 'c'};
		String s = "name";
		tree.add(keys, s);
	}
	
	/**
	 * Test to determine if add returns false when given a keyarr of null
	 */
	@Test
	public void addTest2(){
		Character[] keys = null;
		String s = "name";
		boolean result = tree.add(keys, s);
		assertEquals(result, false);
	}
	
	/**
	 * Tests to determine if add returns false when given an empty array
	 */
	@Test
	public void addTest3(){
		Character[] keys = {};
		String s = "name";
		boolean result = tree.add(keys, s);
		assertEquals(result, false);
	}
	
	/**
	 * Tests to determine if add return false when given a null aValue
	 */
	@Test
	public void addTest4(){
		Character[] keys = {'a', 'b', 'c'};
		String s = null;
		boolean result = tree.add(keys, s);
		assertEquals(result, false);
	}
	
	/**
	 * Tests to determine if the resulting tree is in the right order when adding to an
	 * empty tree
	 */
	@Test
	public void addTest5(){
		Character[] keys = {'a', 'b', 'c'};
		String s = "letters";
		tree.add(keys, s);
		Node cur = tree.root.child;
		for(int i = 0; i < keys.length; i++){
			assertEquals(cur.key, keys[i]);
			cur = cur.child;
		}
	}
	
	/**
	 * Tests to determine if the resulting tree is in the right order when adding
	 * to a tree with the prefix ending in the middle of the tree
	 */
	@Test
	public void addTest6(){
		Character[] keys = {'a', 'b', 'c', 'd', 'e'};
		String s = "letters";
		tree.add(keys, s);
		Character[] keys2 = {'a', 'b', 'c', 's', 't', 'u', 'v'};
		String s2 = "more";
		tree.add(keys2, s2);
		Node cur = tree.root.child;
		assertEquals(cur.key, keys2[0]);
		cur = cur.child;
		assertEquals(cur.key, keys2[1]);
		cur = cur.child;
		assertEquals(cur.key, keys2[2]);
		cur = cur.child.next;
		assertEquals(cur.key, keys2[3]);
		cur = cur.child;
		assertEquals(cur.key, keys2[4]);
		cur = cur.child;
		assertEquals(cur.key, keys2[5]);
		cur = cur.child;
		assertEquals(cur.key, keys2[6]);
		assertEquals(cur.value, "more");
	}
	
	/**
	 * Tests to determine if the resulting tree is in the right order when adding
	 * to a tree with the prefix ending in the end of the tree
	 */
	@Test
	public void addTest7(){
		Character[] keys = {'a', 'b', 'c', 'd', 'e'};
		String s = "letters";
		tree.add(keys, s);
		Character[] keys2 = {'a', 'b', 'c', 'd', 'e', 'x', 'y', 'z'};
		String s2 = "more";
		tree.add(keys2, s2);
		Node cur = tree.root.child;
		for(int i = 0; i < keys2.length; i++){
			assertEquals(cur.key, keys2[i]);
			if(i == 7){
				assertEquals(cur.value, "more");
			}
			cur = cur.child;
		}
	}
	
	/**
	 * Tests if prefix returns null if the given keyarr is null
	 */
	@Test
	public void prefixTest1(){
		Character[] keys = null;
		Character[] result = tree.prefix(keys);
		assertNull(result);
	}
	
	/**
	 * Tests if prefix returns null if the given keyarr is length 0
	 */
	@Test
	public void prefixTest2(){
		Character[] keys = {};
		Character[] result = tree.prefix(keys);
		assertNull(result);
	}
	
	/**
	 * Tests prefix when there is one branch and the prefix is part of the tree
	 * and when the prefix is the entire tree
	 */
	@Test
	public void prefixTest3(){
		Character[] keys = {'a', 'b', 'c', 'd', 'e'};
		String s = "letters";
		tree.add(keys, s);
		Character[] prefix = {'a', 'b', 'c', 's', 't'};
		Character[] result = tree.prefix(prefix);
		Character[] expected = {'a', 'b', 'c'};
		assertArrayEquals(result, expected);
		Character[] prefix2 = {'a', 'b', 'c', 'd', 'e'};
		Character[] result2 = tree.prefix(prefix2);
		Character[] expected2 = {'a', 'b', 'c', 'd', 'e'};
		assertArrayEquals(result2, expected2);
	}
	
	/**
	 * Tests prefix when there are multiple branches and the prefix is part of
	 * the extend branch
	 */
	@Test
	public void prefixTest4(){
		Character[] keys = {'a', 'b', 'c', 'd', 'e'};
		tree.add(keys, "letters");
		Character[] keys2 = {'a', 'b', 's', 't', 'u'};
		tree.add(keys2, "second");
		Character[] keyarr = {'a', 'b', 's', 't', 'z'};
		Character[] result = tree.prefix(keyarr);
		Character[] expected = {'a', 'b', 's', 't'};
		assertArrayEquals(result, expected);
	}
	
	/**
	 * Tests if search returns null when given an array that is null or empty
	 */
	@Test
	public void searchTest1(){
		Character[] keys = null;
		String result = tree.search(keys);
		assertNull(result);
		Character[] keys2 = {};
		String result2 = tree.search(keys2);
		assertNull(result2);
	}
	
	/**
	 * Tests if search returns the right result when the tree has one branch
	 */
	@Test
	public void searchTest2(){
		Character[] keys = {'a', 'b', 'c', 'd', 'e'};
		tree.add(keys, "letters");
		String result = tree.search(keys);
		assertEquals(result, "letters");
	}
	
	/**
	 * Tests if search return the right result when the tree has multiple branches
	 */
	@Test
	public void searchTest3(){
		Character[] keys = {'a', 'b', 'c', 'd', 'e'};
		tree.add(keys, "letters");
		Character[] keys2 = {'f', 'g', 'h', 'i', 'j'};
		tree.add(keys2, "more");
		Character[] keys3 = {'f', 'g', 'h', 'x', 'y'};
		tree.add(keys3, "last");
		String result = tree.search(keys3);
		assertEquals(result, "last");
	}
	
	/**
	 * Tests if remove returns null when keyarr is null or empty
	 */
	@Test
	public void removeTest1(){
		Character[] keys = null;
		String result = tree.remove(keys);
		assertNull(result);
		Character[] keys2 = {};
		String result2 = tree.remove(keys2);
		assertNull(result2);
	}
	
	/**
	 * Tests if remove throws a NullPointerException when there is a null item in the array
	 */
	@Test(expected = NullPointerException.class)
	public void removeTest2(){
		Character[] keys = {'a', 'b', null, 'c'};
		tree.remove(keys);
	}
	
	/**
	 * Tests if remove modifies the tree correctly and returns the right value when
	 * there is just one branch
	 */
	@Test
	public void removeTest3(){
		Character[] keys = {'a', 'b', 'c', 'd', 'e'};
		tree.add(keys, "letters");
		String result = tree.remove(keys);
		assertEquals(result, "letters");
		Node expected = tree.root.child;
		assertNull(expected);
	}
	
	/**
	 * Tests if remove modifies the tree correctly and returns the right value when
	 * there are three branches and the one to be removed is the leftmost branch
	 */
	@Test
	public void removeTest4(){
		Character[] keys = {'a', 'b', 'c', 'd', 'e'};
		tree.add(keys, "letters");
		Character[] keys2 = {'a', 'f', 'g', 'h', 'i'};
		tree.add(keys2, "more");
		Character[] keys3 = {'a', 'j', 'k', 'l', 'm'};
		tree.add(keys3, "last");
		String result = tree.remove(keys);
		assertEquals(result, "letters");
		Node cur = tree.root;
		for(int i = 0; i < keys2.length; i++){
			cur = cur.child;
			assertEquals(cur.key, keys2[i]);
		}
	}
	
	/**
	 * Tests if remove modifies the tree correctly and returns the right value when
	 * there are three branches and the one to be removed is the middle branch
	 */
	@Test
	public void removeTest5(){
		Character[] keys = {'a', 'b', 'c', 'd', 'e'};
		tree.add(keys, "letters");
		Character[] keys2 = {'a', 'f', 'g', 'h', 'i'};
		tree.add(keys2, "more");
		Character[] keys3 = {'a', 'j', 'k', 'l', 'm'};
		tree.add(keys3, "last");
		String result = tree.remove(keys2);
		assertEquals(result, "more");
		Node cur = tree.root;
		for(int i = 0; i < keys2.length; i++){
			cur = cur.child;
			assertEquals(cur.key, keys[i]);
		}
	}
	
	/**
	 * Tests if remove modifies the tree correctly and returns the right value when
	 * there are three branches and the one to be removed is the right branch
	 */
	@Test
	public void removeTest6(){
		Character[] keys = {'a', 'b', 'c', 'd', 'e'};
		tree.add(keys, "letters");
		Character[] keys2 = {'a', 'f', 'g', 'h', 'i'};
		tree.add(keys2, "more");
		Character[] keys3 = {'a', 'j', 'k', 'l', 'm'};
		tree.add(keys3, "last");
		String result = tree.remove(keys3);
		assertEquals(result, "last");
		Node cur = tree.root.child.child.next.next;
		assertNull(cur);
	}
}