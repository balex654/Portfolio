package edu.iastate.cs228.hw3;

import java.util.List;
import java.util.ListIterator;

public class ListsExampleMain {
	public static void main(String[] args)
	  {
	    System.out.println("A node reference or index is shown in the parentheses after the element in the node");
	    ListsExample<String> list = new ListsExample<String>();
	    list.add("TGCAA");
	    
	    System.out.println();
	    
	    list.remove_Demo("ATGCT");
	    list.add(null);
	    list.remove_Demo(null);
	    list.add("CGACG");
	    list.add("GTCAT");
	    list.remove_Demo("ATG");
	   
	  }
}
