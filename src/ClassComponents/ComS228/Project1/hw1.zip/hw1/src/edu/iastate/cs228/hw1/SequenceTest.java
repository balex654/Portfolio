package edu.iastate.cs228.hw1;

import static org.junit.Assert.*;

import org.junit.Test;

public class SequenceTest {

	/**
	 * Tests if the constructor throws an IllegalArgumentException when given an
	 * invalid character array
	 */
	@Test(expected = IllegalArgumentException.class)
	public void constructorTest() {
		char[] a = { '0', '1', '2' };
		Sequence test = new Sequence(a);
	}

	/**
	 * Tests if the constructor copies the array to seqarr if the given array is
	 * valid
	 */
	@Test
	public void constructorTest2() {
		char[] a = { 'A', 'B', 'C' };
		Sequence test = new Sequence(a);
		assertArrayEquals(test.seqarr, a);
	}

	/**
	 * Tests if the seqLength() method functions properly
	 */
	@Test
	public void seqLengthTest() {
		char[] a = { 'A', 'B', 'C' };
		char[] b = {'a', 'b', 'c', 'd', 'e'};
		Sequence test2 = new Sequence(b);
		Sequence test = new Sequence(a);
		assertEquals(test.seqLength(), 3);
		assertEquals(test2.seqLength(), 5);
	}

	/**
	 * Tests if the getSeq() method functions properly
	 */
	@Test
	public void getSeqTest(){
		char[] a = {'a', 'b', 'c'};
		Sequence test = new Sequence(a);
		char[] b = test.getSeq();
		assertArrayEquals(test.seqarr, b);
	}
	
	/**
	 * Tests if the toString() method functions properly
	 */
	@Test
	public void toStringTest(){
		char[] a = {'a', 'b', 'c'};
		Sequence test = new Sequence(a);
		String string = test.toString();
		assertEquals(string, "abc");
	}
	
	/**
	 * Tests if the isValidLetter method functions properly when given a valid letter
	 */
	@Test
	public void isValidLetterTest(){
		char a = 'A';
		char[] array = {'a', 'b', 'c'};
		Sequence test = new Sequence(array);
		boolean result = test.isValidLetter(a);
		assertEquals(result, true);
	}
	
	/**
	 * Tests if the isValidLetter method functions properly when given an invalid letter
	 */
	@Test
	public void isValidLetterTests(){
		char a = '1';
		char[] array = {'a', 'b', 'c'};
		Sequence test = new Sequence(array);
		boolean result = test.isValidLetter(a);
		assertEquals(result, false);
	}
	
	/**
	 * Tests if the equals method functions properly when given a non char[] object
	 */
	@Test
	public void equalsTest(){
		char[] array = {'a', 'b', 'c'};
		Sequence test = new Sequence(array);
		String s = "not a char[]";
		boolean result = test.equals(s);
		assertEquals(result, false);
	}
	
	/**
	 * Tests if the equals method functions properly when given a char[] object that isn't equal to seqarr
	 */
	@Test
	public void equalsTest2(){
		char[] array = {'a', 'b', 'c'};
		Sequence test = new Sequence(array);
		char[] array2 = {'b', 'b', 'c'};
		boolean result = test.equals(array2);
		assertEquals(result, false);
	}
	
	/**
	 * Tests if the equals method functions properly when given a char[] object that is equal to seqarr
	 */
	@Test
	public void equalsTest3(){
		char[] array = {'A', 'g', 'C'};
		Sequence test = new Sequence(array);
		char[] array2 = {'A', 'g', 'C'};
		boolean result = test.equals(array2);
		assertEquals(result, true);
	}
}
