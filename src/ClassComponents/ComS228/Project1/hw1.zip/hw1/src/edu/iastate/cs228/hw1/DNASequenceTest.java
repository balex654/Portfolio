package edu.iastate.cs228.hw1;

import static org.junit.Assert.*;

import org.junit.Test;

public class DNASequenceTest {
	
	/**
	 * Tests if the isValidLetterTest works if given a valid letter
	 */
	@Test
	public void isValidLetterTest(){
		char[] a = {'a', 'c', 'g'};
		DNASequence test = new DNASequence(a);
		boolean result = test.isValidLetter('a');
		assertEquals(result, true);
	}
	
	/**
	 * Tests if the isValidLetterTest works if given an invalid letter
	 */
	@Test
	public void isValidLetterTest2(){
		char[] a = {'a', 'c', 'g'};
		DNASequence test = new DNASequence(a);
		boolean result = test.isValidLetter('b');
		assertEquals(result, false);
	}
	
	/**
	 * Tests if the getReverseCompSeq works when given a valid array with all possible characters
	 */
	@Test
	public void getReverseCompSeqTest(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		DNASequence test = new DNASequence(a);
		char[] rev = test.getReverseCompSeq();
		char[] expected = {'a','c','g','t','A','C','G','T'};
		assertArrayEquals(rev, expected);
	}
	
	/**
	 * Tests if reverseComplement modifies the seqarr correctly
	 */
	@Test
	public void reverseComplementTest(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		DNASequence test = new DNASequence(a);
		char[] reverse = test.getReverseCompSeq();
		test.reverseComplement();
		assertArrayEquals(test.getSeq(), reverse);
	}
}
