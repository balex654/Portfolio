package edu.iastate.cs228.hw1;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProteinSequenceTest {
	
	/**
	 * These test if isValidLetter returns true when given a valid letter 
	 */
	@Test
	public void isValidLetterTest() {
		char[] a = {'A', 'T', 'G'};
		ProteinSequence test = new ProteinSequence(a);
		boolean result = test.isValidLetter('A');
		assertEquals(result, true);
	}
	@Test
	public void isValidLetterTest2() {
		char[] a = {'A', 'T', 'G'};
		ProteinSequence test = new ProteinSequence(a);
		boolean result = test.isValidLetter('a');
		assertEquals(result, true);
	}
	@Test
	public void isValidLetterTest3() {
		char[] a = {'A', 'T', 'G'};
		ProteinSequence test = new ProteinSequence(a);
		boolean result = test.isValidLetter('L');
		assertEquals(result, true);
	}
	@Test
	public void isValidLetterTest4() {
		char[] a = {'A', 'T', 'G'};
		ProteinSequence test = new ProteinSequence(a);
		boolean result = test.isValidLetter('l');
		assertEquals(result, true);
	}
	@Test
	public void isValidLetterTest5() {
		char[] a = {'A', 'T', 'G'};
		ProteinSequence test = new ProteinSequence(a);
		boolean result = test.isValidLetter('Y');
		assertEquals(result, true);
	}
	@Test
	public void isValidLetterTest6() {
		char[] a = {'A', 'T', 'G'};
		ProteinSequence test = new ProteinSequence(a);
		boolean result = test.isValidLetter('y');
		assertEquals(result, true);
	}
	
	/**
	 * These test if isValidLetter returns false when given an invalid letter
	 */
	@Test
	public void isValidLetterTest7() {
		char[] a = {'A', 'T', 'G'};
		ProteinSequence test = new ProteinSequence(a);
		boolean result = test.isValidLetter('B');
		assertEquals(result, false);
	}
	@Test
	public void isValidLetterTest8() {
		char[] a = {'A', 'T', 'G'};
		ProteinSequence test = new ProteinSequence(a);
		boolean result = test.isValidLetter('Z');
		assertEquals(result, false);
	}
}
