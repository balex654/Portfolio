package edu.iastate.cs228.hw1;

import static org.junit.Assert.*;

import org.junit.Test;

public class CodingDNASequenceTest {
	
	/**
	 * Tests if checkStartCodon retruns false if seqarr.length is less than three
	 */
	@Test
	public void checkStartCodonTest() {
		char[] a = {'a','c'};
		CodingDNASequence test = new CodingDNASequence(a);
		assertEquals(test.checkStartCodon(), false);
	}
	
	/**
	 * Tests if checkStartCodon retruns true if the first three characters in the array 
	 * seqarr are A/a, T/t, G/g in this order (case insensitive)
	 */
	@Test
	public void checkStartCodonTest2() {
		char[] a = {'A','t','G'};
		CodingDNASequence test = new CodingDNASequence(a);
		assertEquals(test.checkStartCodon(), true);
	}
	@Test
	public void checkStartCodonTest3() {
		char[] a = {'a','T','g'};
		CodingDNASequence test = new CodingDNASequence(a);
		assertEquals(test.checkStartCodon(), true);
	}
	
	/**
	 * Tests if checkStartCodon retruns false if the letters are not in the right order
	 */
	@Test
	public void checkStartCodonTest4() {
		char[] a = {'t','t','G'};
		CodingDNASequence test = new CodingDNASequence(a);
		assertEquals(test.checkStartCodon(), false);
	}
	
	/**
	 * Tests if translate throws a RuntimeException error when checkStartCodon is false
	 */
	@Test(expected = RuntimeException.class)
	public void translateTest(){
		char[] a = {'t','t','G'};
		CodingDNASequence test = new CodingDNASequence(a);
		test.translate();
	}
	
	/**
	 * Tests translate when seqarr has start codon and is a multiple of three
	 */
	@Test
	public void translateTest2(){
		char[] a = {'A', 'T', 'G', 'A', 'C', 'T', 'G', 'T', 'A'};
		CodingDNASequence test = new CodingDNASequence(a);
		char[] result = test.translate();
		char[] expected = {'M','T','V'};
		assertArrayEquals(result, expected);
	}
	
	/**
	 * Tests translate when seqarr has start codon and is a multiple of three with 
	 * remainder of one
	 */
	@Test
	public void translateTest3(){
		char[] a = {'A', 'T', 'G', 'A', 'C', 'T', 'G', 'T', 'A', 'C'};
		CodingDNASequence test = new CodingDNASequence(a);
		char[] result = test.translate();
		char[] expected = {'M','T','V'};
		assertArrayEquals(result, expected);
	}
	
	/**
	 * Tests translate when seqarr has start codon and is a multiple of three with 
	 * remainder of two
	 */
	@Test
	public void translateTest4(){
		char[] a = {'A', 'T', 'G', 'A', 'C', 'T', 'G', 'T', 'A', 'C', 'G'};
		CodingDNASequence test = new CodingDNASequence(a);
		char[] result = test.translate();
		char[] expected = {'M','T','V'};
		assertArrayEquals(result, expected);
	}
}