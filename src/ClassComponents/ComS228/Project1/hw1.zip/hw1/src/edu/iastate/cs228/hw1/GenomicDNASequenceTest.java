package edu.iastate.cs228.hw1;

import static org.junit.Assert.*;

import org.junit.Test;

public class GenomicDNASequenceTest {
	
	/**
	 * Tests if the constructor correctly creates the iscoding array
	 */
	@Test
	public void constructorTest(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		boolean[] expected = new boolean[8];
		for(int i = 0; i < expected.length; i++){
			expected[i] = false;
		}
		assertArrayEquals(test.iscoding, expected);
	}
	
	/**
	 * Tests if markCoding thows an error if the input is invalid
	 */
	@Test(expected = IllegalArgumentException.class)
	public void markCodingTest(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		test.markCoding(-1, -1);
	}
	
	/**
	 * Tests if markCoding throws an error if the input is greater than or equal to slen
	 */
	@Test(expected = IllegalArgumentException.class)
	public void markCodingTest2(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		test.markCoding(9, 9);
	}
	
	/**
	 * Tests markCoding when the first is greater than the last
	 */
	@Test
	public void markCodingTest3(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		test.markCoding(5, 4);
		boolean[] expected = {false, false, true, true, false, false, false, false};
		assertArrayEquals(test.iscoding, expected);
	}
	
	/**
	 * Tests markCoding when the last is greater than the first
	 */
	@Test
	public void markCodingTest4(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		test.markCoding(4, 6);
		boolean[] expected = {false, false, false, false, true, true, true, false};
		assertArrayEquals(test.iscoding, expected);
	}
	
	/**
	 * Tests if extractExons thows an IllegalArgumentException if exonpos is length 0
	 */
	@Test(expected = IllegalArgumentException.class)
	public void extractExonsTest(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		int[] exons = new int[0];
		test.extractExons(exons);
	}
	
	/**
	 * Tests if extractExons thows an IllegalArgumentException if exonpos length is not divisable
	 * by two
	 */
	@Test(expected = IllegalArgumentException.class)
	public void extractExonsTest2(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		int[] exons = new int[5];
		test.extractExons(exons);
	}
	
	/**
	 * Tests if extractExons throws IllegalArgumentException if an element in exonpos is less than 0
	 */
	@Test(expected = IllegalArgumentException.class)
	public void extractExonsTest3(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		int[] exons = {1,2,3,4,5,-3};
		test.extractExons(exons);
	}
	
	/**
	 * Tests if extractExons throws IllegalArgumentException if an element in exonpos is greater than
	 * or equal to seqLength()
	 */
	@Test(expected = IllegalArgumentException.class)
	public void extractExonsTest4(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		int[] exons = {1,2,3,4,9,3};
		test.extractExons(exons);
	}
	
	/**
	 * Tests if extractExons throws IllegalArgumentException if an element in exonpos
	 * is greater than its right neighbor element
	 */
	@Test(expected = IllegalArgumentException.class)
	public void extractExonsTest5(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		int[] exons = {1,2,3,4,5,3};
		test.extractExons(exons);
	}
	
	/**
	 * These tests if extractExons creates the correct array when given an array that is valid
	 */
	@Test
	public void extractExonsTest6(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't', 'A', 'C', 'G', 'T'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		test.markCoding(0, 11);
		int[] exons = {1,3,5,7,9,11};
		char[] expected = {'C', 'G', 'T', 'c', 'g', 't', 'C', 'G', 'T'};
		char[] result = test.extractExons(exons);
		assertArrayEquals(result, expected);
	}
	@Test
	public void extractExonsTest7(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't', 'A', 'C', 'G', 'T'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		test.markCoding(0, 11);
		int[] exons = {0,3,4,7,8,11};
		char[] expected = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't', 'A', 'C', 'G', 'T'};
		char[] result = test.extractExons(exons);
		assertArrayEquals(result, expected);
	}
	@Test
	public void extractExonsTest8(){
		char[] a = {'A', 'C', 'G', 'T', 'a', 'c', 'g', 't', 'A', 'C', 'G', 'T'};
		GenomicDNASequence test = new GenomicDNASequence(a);
		test.markCoding(0, 11);
		int[] exons = {0,2,4,6,8,10};
		char[] expected = {'A', 'C', 'G', 'a', 'c', 'g', 'A', 'C', 'G'};
		char[] result = test.extractExons(exons);
		assertArrayEquals(result, expected);
	}
}
