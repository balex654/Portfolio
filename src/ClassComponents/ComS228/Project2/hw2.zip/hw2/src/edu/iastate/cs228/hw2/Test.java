package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;

public class Test {
	public static void main(String[] args) throws InputMismatchException, FileNotFoundException {
//		/Users/benalexander/School/Java/hw2/src/edu/iastate/cs228/hw2/
//		SelectionSorter sorter = new SelectionSorter("/Users/benalexander/School/Java/hw2/src/edu/iastate/cs228/hw2/text.txt");
//		sorter.sort(1);
		Point[] points = new Point[17];
		points[0] = new Point(0, 0);
		points[1] = new Point(-3, -9);
		points[2] = new Point(0, -10);
		points[3] = new Point(8, 4);
		points[4] = new Point(3, 3);
		points[5] = new Point(-6, 3);
		points[6] = new Point(-2, 1);
		points[7] = new Point(10, 5);
		points[8] = new Point(-7, -10);
		points[9] = new Point(5, -2);
		points[10] = new Point(7, 3);
		points[11] = new Point(10, 5);
		points[12] = new Point(-7, -10);
		points[13] = new Point(0, 8);
		points[14] = new Point(-1, -6);
		points[15] = new Point(-10, 0);
		points[16] = new Point(5, 5);
//		points[0] = new Point(8, 4);
//		points[1] = new Point(5, 5);
//		points[2] = new Point(10, 5);
//		points[3] = new Point(7, 3);
//		points[4] = new Point(1, 5);
//		points[5] = new Point(3, 3);
//		points[6] = new Point(5, -2);
		SelectionSorter sorter = new SelectionSorter("text.txt");
		sorter.sort(2);
		for(int i = 0; i < points.length; i++){
			System.out.println(sorter.points[i].getX() + " " + sorter.points[i].getY());
		}
	}
}
