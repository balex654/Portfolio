package edu.iastate.cs228.hw2;

public class PolarAngleComparatorTest {
	public static void main(String[] args){
		Point p1 = new Point(-3, -9);
		Point p2 = new Point(-7, -10);
		Point r = new Point(-10, 0);
		PolarAngleComparator c = new PolarAngleComparator(r);
		System.out.println(c.compare(p1, p2));
		
	}
}
