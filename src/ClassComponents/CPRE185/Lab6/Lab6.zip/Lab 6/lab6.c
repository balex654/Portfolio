#include <stdio.h>
#include <math.h>
#define TRUE 1

double seconds(double ms);
int mag(double x, double y, double z);
int closeto(double tolerance, double point, double value);

int main (){
	double t;
	double ax;
	double ay;
	double az;
	double fallstart;
	double fallstop;
	double falltime;
	double distance;
	int num = 0;
	int num2 = 0;
	scanf("%lf,%lf,%lf,%lf", &t, &ax, &ay, &az);
	printf("Ok im receiving data\n");
	printf("Im waiting");
	while (mag(ax, ay, az) == 0){
		if ((num % 100) == 0){
			printf(".");
		}
		scanf("%lf,%lf,%lf,%lf", &t, &ax, &ay, &az);
		++num;
		fflush(stdout);
	}
	printf("\n");
	fallstart = t;
	printf("help me! Im falling");
	while (mag(ax, ay, az) == 1){
		if ((num2 % 100) == 0){
			printf("!");
		}
		scanf("%lf,%lf,%lf,%lf", &t, &ax, &ay, &az);
		++num2;
		fflush(stdout);
	}
	printf("\n");
	fallstop = t;
	falltime = seconds(fallstop - fallstart);
	distance = .5 * 9.8 * falltime * falltime;
	printf("Ouch, I fell %lf meter in %lf seconds\n", distance, falltime);
}

double seconds(double ms){
	double seconds;	
	seconds = ms / 1000;
	return seconds;
}

int closeto(double tolerance, double point, double value){
	if(tolerance > fabs(point - value)){
		return 1;
	}
	else {
		return 0;
	}
}

int mag(double x, double y, double z){
	double mag;
	
	mag = sqrt((x * x) + (y * y) + (z * z));
	
	if (closeto(.1, 1, mag) == 1){
		return 0;
	}
	else {
		return 1;
	}
}