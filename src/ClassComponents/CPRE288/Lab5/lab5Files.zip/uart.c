/**
*
* 	@file  uart.c
*
*   @date 2/14/2018 <3
*/

#include "uart.h"

/**
 * @brief sets all necessary registers to enable the uart 1 module.
 */
void uart_init(void){
    SYSCTL_RCGCUART_R = 0x02;
	UART1_CTL_R &= 0xFFFFFFFE;
	UART1_IBRD_R = 0x08;
	UART1_FBRD_R = 44;
	UART1_LCRH_R = 0x70;
	UART1_CC_R = 0x0;
	UART1_CTL_R |= 0x1;
}

/**
 * @brief Sends a single 8 bit character over the uart 1 module.
 * @param data the data to be sent out over uart 1
 */
void uart_sendChar(char data){
	UART1_DR_R = data;
}

/**
 * @brief polling receive an 8 bit character over uart 1 module.
 * @return the character received or a -1 if error occured
 */
int uart_receive(void){
	char UartDataIn = 0;
	UartDataIn = (char)(UART1_DR_R &= 0x000000FF);
	return UartDataIn;
}

/**
 * @brief sends an entire string of character over uart 1 module
 * @param data pointer to the first index of the string to be sent
 */
void uart_sendStr(const char *data){
	char endC = 5;
	int i = 0;
	while (!(endC == '\0')){
		if ( !(UART1_FR_R & 0x20)){
			UART1_DR_R = data[i];
			endC = data[i];
			i++;
		}
	}
}
