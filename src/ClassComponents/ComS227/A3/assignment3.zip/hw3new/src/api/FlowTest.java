package api;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import hw3.FlowGame;
import hw3.Util;

public class FlowTest {
	public static void main(String[] args) throws FileNotFoundException{
		String[] descriptor = {"------","-OR-G-","BG-OR-","------","B-----"};
		Flow[] flow;
		flow = Util.createFlowsFromStringArray(descriptor);
		ArrayList<FlowGame> games = new ArrayList<FlowGame>();
		//games = Util.readFile("game.txt");
		FlowGame game = new FlowGame(descriptor);
		games.set(0, game);
		
//		games.get(1).startFlow(0, 0);
//		games.get(1).addCell(1, 0);
//		games.get(1).addCell(1, 1);
//		games.get(1).addCell(1, 2);
//		games.get(1).endFlow();
//		
//		games.get(1).startFlow(0, 1);
//		games.get(1).addCell(0, 2);
//		games.get(1).addCell(0, 3);
//		games.get(1).endFlow();
		
		//System.out.println(games.get(0).getCurrent());
//		Flow[] temp = games.get(0).getAllFlows();
//		for(int i = 0; i < temp.length; i++){
//			System.out.println(temp[i]);
//		}
//		System.out.println("");
//		Flow[] temp2 = games.get(1).getAllFlows();
//		for(int i = 0; i < temp2.length; i++){
//			System.out.println(temp2[i]);
//		}
//		System.out.println("");
//		Flow[] temp3 = games.get(2).getAllFlows();
//		for(int i = 0; i < temp3.length; i++){
//			System.out.println(temp3[i]);
//		}
		
		
	}
}
