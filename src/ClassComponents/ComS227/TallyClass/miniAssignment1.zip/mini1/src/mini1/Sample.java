package mini1;

public class Sample {
	public static void main(String[] args){
		String a = "";
		for(int i = 0; i < 10; i++){
			 a = a.concat("H");
		}
		System.out.println(a);
	}
}
