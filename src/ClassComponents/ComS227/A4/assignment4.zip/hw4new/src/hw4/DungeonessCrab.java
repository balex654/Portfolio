package hw4;

import graph.Cell;

/**
 * Randomly moves around according to the cycle of food. A "D" in a map file.
 * @author Ben Alexander
 */
public class DungeonessCrab extends Food{
	/**
	 * Has the same setup as Food.handle except when timer is MAX_FOOD_TIMER - 1
	 * the cell is moved to a random open cell adjacent to the current cell. Also
	 * the color is changed when the condition is true.
	 * @param cell - The cell that this state belongs to
	 */
	public void handle(Cell cell){
		super.handle(cell);
		if(super.isZero()){
			cell.moveState(cell.getRandomOpen());
		}
	}
	
	/**
	 * determines the character that represents DungeonessCrab
	 * @return the character the DungeonessCrab represents
	 */
	public char toChar(){
		return 'D';
	}
}