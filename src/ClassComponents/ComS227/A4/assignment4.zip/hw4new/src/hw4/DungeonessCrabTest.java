package hw4;

import graph.Cell;
import main.Config;
import state.State;

public class DungeonessCrabTest {
	public static void main(String[] args) {
		// Create a cell whose state is DungeonessCrab and
		// give it an open neighbor. Note the color and
		// polygon won't be used, so we can leave them null
		Cell c = new Cell(null, null);
		State myCrab = new DungeonessCrab();
		c.setState(myCrab);
		Cell c2 = new Cell(null, null);
		Cell[] neighbors = { c2 };
		c.setNeighbors(neighbors);

		// check initial values
		System.out.println(c.getState() == myCrab); // should be true
		System.out.println(c2.getState()); // should be null

		// do updates (calls handle())
		for (int i = 0; i < Config.MAX_FOOD_TIMER; ++i) {
			c.update();
		}

		// crab state should have moved to neighbor
		System.out.println(c.getState()); // should be null
		System.out.println(c2.getState() == myCrab); // should be true
	}
}
