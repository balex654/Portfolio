package hw4;

import java.awt.Color;
import java.util.Random;

import color.ColorGenerator;

/**
 * Randomly creates one of 6 dark rainbow colors:
 * Blue, Green, Yellow, Orange, Red, Purple, Blue.
 * @author Ben Alexander
 *
 */
public class RainbowColorGenerator implements ColorGenerator{
	
	/**
	 * Creates a new RainbowColorGenerator
	 */
	public RainbowColorGenerator(){}
	
	/**
	 * Each of these statements creates a Color with their respective values 
	 */
	private static final Color red = new Color(0.25f,0.0f,0.0f);
	private static final Color orange = new Color(.25f,0.125f,0.0f);
	private static final Color yellow = new Color(.25f,.25f,0.0f);
	private static final Color green = new Color(0,.25f,0);
	private static final Color blue = new Color(0.0f,0.0f,0.25f);
	private static final Color purple = new Color(.25f,0.0f,0.25f);
	
	/**
	 * Randomly makes a new color from one of the six Colors 
	 * @return A Color
	 */
	public java.awt.Color createColor(){
		Random rand = new Random();
		int num = rand.nextInt(6);
		
		if(num == 0){
			return red;
		}
		else if(num == 1){
			return orange;
		}
		else if(num == 2){
			return yellow;
		}
		else if(num == 3){
			return green;
		}
		else if(num == 4){
			return blue;
		}
		else if(num == 5){
			return purple;
		}
		else{
			return null;
		}
	}
}
