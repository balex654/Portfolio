package hw4;

import graph.Cell;

public class CellUtilTest {
	public static void main(String[] args) {
		/*
		Cell c0 = new Cell(null, null);
		Cell c1 = new Cell(null, null);
		Cell c2 = new Cell(null, null);
		c2.setNeighbors(new Cell[] {});
		c1.setNeighbors(new Cell[] { c2 });
		c0.setNeighbors(new Cell[] { c1 });

		c0.recalculateMouseDistances();

		System.out.println(c0.getMouseDistance()); // expected 20
		System.out.println(c1.getMouseDistance()); // expected 19
		System.out.println(c2.getMouseDistance()); // expected 18
		*/
		Cell c1 = new Cell(null, null);
		Cell c2 = new Cell(null, null);
		Cell c3 = new Cell(null, null);
		Cell c4 = new Cell(null, null);
		Cell c5 = new Cell(null, null);
		Cell c6 = new Cell(null, null);
		Cell c7 = new Cell(null, null);
		Cell c8 = new Cell(null, null);
		Cell c9 = new Cell(null, null);
		Cell c10 = new Cell(null, null);
		Cell c11 = new Cell(null, null);
		Cell c12 = new Cell(null, null);
		Cell c13 = new Cell(null, null);
		Cell c14 = new Cell(null, null);
		
		c1.setNeighbors(new Cell[]{c6, c2});
		c2.setNeighbors(new Cell[]{c1, c6, c5, c3});
		c3.setNeighbors(new Cell[]{c2,c5,c4});
		c4.setNeighbors(new Cell[]{c3,c5,c8});
		c5.setNeighbors(new Cell[]{c2,c6,c7,c8,c4,c3});
		c6.setNeighbors(new Cell[]{c1, c2, c5, c7, c14});
		c7.setNeighbors(new Cell[]{c14, c13, c10, c8, c5, c6});
		c8.setNeighbors(new Cell[]{c4, c5, c7, c10, c9});
		c9.setNeighbors(new Cell[]{c8,c10,c11});
		c10.setNeighbors(new Cell[]{c7,c8,c9,c11,c12,c13});
		c11.setNeighbors(new Cell[]{c9,c10,c12});
		c12.setNeighbors(new Cell[]{c13,c10,c11});
		c13.setNeighbors(new Cell[]{c14,c7,c10,c12});
		c14.setNeighbors(new Cell[]{c6,c7,c13});
		
		c1.recalculateMouseDistances();
		
		// Comments that follow are the expected values
		
		System.out.println(c1.getMouseDistance());	// 20
		System.out.println(c2.getMouseDistance());	// 19
		System.out.println(c3.getMouseDistance());	// 18
		System.out.println(c4.getMouseDistance());	// 17
		System.out.println(c5.getMouseDistance());	// 18
		System.out.println(c6.getMouseDistance());	// 19
		System.out.println(c7.getMouseDistance());	// 18
		System.out.println(c8.getMouseDistance());	// 17
		System.out.println(c9.getMouseDistance());	// 16
		System.out.println(c10.getMouseDistance());	// 17
		System.out.println(c11.getMouseDistance());	// 16
		System.out.println(c12.getMouseDistance());	// 16
		System.out.println(c13.getMouseDistance());	// 17
		System.out.println(c14.getMouseDistance());	// 18
	}
}
