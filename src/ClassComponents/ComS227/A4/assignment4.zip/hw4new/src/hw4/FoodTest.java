package hw4;

import graph.Cell;

public class FoodTest {
	public static void main(String[] args) {
		Food f = new Food();
		System.out.println(f.getColor().getAlpha());
		System.out.println(f.toChar()); // Should be 'F'
		System.out.println(f.isPassable()); // Should be true

		Cell c = new Cell(null, null); // color and polygon don't matter, since
										// we don't plan to draw it
		f.handle(c);
		System.out.println(f.getColor().getAlpha()); // Alpha should change as
														// you call handle
		f.handle(c);
		System.out.println(f.getColor().getAlpha());// Alpha should change as
														// you call handle
		f.handle(c);
		System.out.println(f.getColor().getAlpha());
	}
}
