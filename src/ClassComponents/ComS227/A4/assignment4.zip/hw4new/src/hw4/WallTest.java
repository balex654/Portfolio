package hw4;

public class WallTest {
	public static void main(String[] args) {
		Wall w = new Wall();
		System.out.println(w.getColor()); // Should print
											// 'java.awt.Color[r=255,g=255,b=255]'
		System.out.println(w.toChar()); // Should print '#'
		System.out.println(w.isPassable()); // Should print false
	}
}
